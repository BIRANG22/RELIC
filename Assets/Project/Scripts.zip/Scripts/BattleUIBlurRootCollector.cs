using System;
using System.Collections.Generic;
using UnityEngine;

public static class BattleUIBlurRootCollector
{
    private const string BattleHudCanvasName = "BattleHUDCanvas";
    private const string MenuRootName = "MenuRoot";
    private const string MenuPanelName = "MenuPanel";

    public static void ConfigureForPanel(GameObject panelRoot)
    {
        if (panelRoot == null)
            return;

        UIBlurBackground[] blurBackgrounds =
            panelRoot.GetComponentsInChildren<UIBlurBackground>(true);
        if (blurBackgrounds == null || blurBackgrounds.Length == 0)
            return;

        List<GameObject> roots = Collect(panelRoot.transform);
        for (int i = 0; i < blurBackgrounds.Length; i++)
        {
            UIBlurBackground blurBackground = blurBackgrounds[i];
            if (blurBackground == null)
                continue;

            blurBackground.SetRuntimeBlurredUiRoots(roots);
        }
    }

    public static void ConfigureForMenuPanel(GameObject menuPanel)
    {
        UIBlurBackground blurBackground = UIBlurBackground.EnsureForPanel(menuPanel);
        if (blurBackground == null)
            return;

        blurBackground.SetRuntimeBlurredUiRoots(Collect(menuPanel.transform));
    }

    private static List<GameObject> Collect(Transform ownerTransform)
    {
        List<GameObject> roots = new();

        AddActiveBattleHudCanvases(roots, ownerTransform);
        AddActivePanelRoots<BattleRewardPanelUI>(roots, ownerTransform);
        AddActivePanelRoots<BattleRewardEquipPanelUI>(roots, ownerTransform);

        return roots;
    }

    private static void AddActiveBattleHudCanvases(List<GameObject> roots, Transform ownerTransform)
    {
        Canvas[] canvases = UnityEngine.Object.FindObjectsByType<Canvas>(
            FindObjectsInactive.Exclude,
            FindObjectsSortMode.None);

        for (int i = 0; i < canvases.Length; i++)
        {
            Canvas canvas = canvases[i];
            if (canvas == null || !canvas.gameObject.activeInHierarchy)
                continue;

            if (!string.Equals(canvas.gameObject.name, BattleHudCanvasName, StringComparison.Ordinal))
                continue;

            AddUniqueRoot(roots, canvas.gameObject, ownerTransform);
        }
    }

    private static void AddActivePanelRoots<T>(List<GameObject> roots, Transform ownerTransform)
        where T : Component
    {
        T[] panels = UnityEngine.Object.FindObjectsByType<T>(
            FindObjectsInactive.Exclude,
            FindObjectsSortMode.None);

        for (int i = 0; i < panels.Length; i++)
        {
            T panel = panels[i];
            if (panel == null || !panel.gameObject.activeInHierarchy)
                continue;

            AddUniqueRoot(roots, panel.gameObject, ownerTransform);
        }
    }

    private static void AddUniqueRoot(List<GameObject> roots, GameObject root, Transform ownerTransform)
    {
        if (roots == null || root == null || roots.Contains(root))
            return;

        Transform rootTransform = root.transform;
        if (IsSelfOrChildOf(ownerTransform, rootTransform))
            return;

        if (IsMenuRootOrChild(rootTransform) || string.Equals(root.name, MenuPanelName, StringComparison.Ordinal))
            return;

        roots.Add(root);
    }

    private static bool IsSelfOrChildOf(Transform ownerTransform, Transform target)
    {
        return ownerTransform != null &&
               target != null &&
               (target == ownerTransform || target.IsChildOf(ownerTransform));
    }

    private static bool IsMenuRootOrChild(Transform transform)
    {
        Transform current = transform;
        while (current != null)
        {
            if (string.Equals(current.name, MenuRootName, StringComparison.Ordinal))
                return true;

            current = current.parent;
        }

        return false;
    }
}
