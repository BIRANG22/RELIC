using System;
using System.Collections.Generic;
using System.Linq;
using Relic.Gameplay.Data;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// �κ� CultureTankPanel/reference���� �÷��̾ �߰��� ��Ḧ ��������
/// ���� ������ ���չ��� �����մϴ�.
/// ��� 3�� �� �ϳ��� �߰��ϸ� ������ ǥ�õǸ�,
/// ��� �������� ������ �� �� ������ �߰��ϱ� ������ ? ���·� �����˴ϴ�.
/// </summary>
[DisallowMultipleComponent]
public sealed class LobbyCompoundReferenceUI : MonoBehaviour
{
    [Header("������ ���")]
    [Tooltip("reference/Scroll View/Viewport/Content �Դϴ�. ����θ� �ڵ����� ã���ϴ�.")]
    [SerializeField] private RectTransform contentRoot;

    [Tooltip("CompoundRecipeSlot �������Դϴ�.")]
    [SerializeField] private CompoundRecipeSlotUI recipeSlotPrefab;

    [Header("��ũ��")]
    [Tooltip("reference/Scroll View�� ScrollRect �Դϴ�. ����θ� �ڵ����� ã���ϴ�.")]
    [SerializeField] private ScrollRect scrollRect;

    [Tooltip("������ ����� ������ �� �Ѿ�� �ʵ��� Clamped�� ����մϴ�.")]
    [SerializeField] private bool forceClampedMovement = true;

    [Header("���� �̸� ǥ��")]
    [Tooltip("reference �Ʒ��� Nameinfo�� �����ϴ� ������Ʈ�Դϴ�. ����θ� �ڵ����� ã���ϴ�.")]
    [SerializeField] private CompoundReferenceNameTooltip nameTooltip;

    [Header("����")]
    [Tooltip("�г��� ���� ���� �߰� ���� ��ȭ�� �ݿ��ϴ� �����Դϴ�.")]
    [Min(0.05f)]
    [SerializeField] private float refreshInterval = 0.25f;

    private readonly List<CompoundRecipeSlotUI> spawnedSlots = new();
    private string lastStateKey = string.Empty;
    private float nextRefreshAt;

    private void Awake()
    {
        ResolveReferences();
        ConfigureScrollRect();
        HideSceneTemplateIfNeeded();
    }

    private void OnEnable()
    {
        ResolveReferences();
        ConfigureScrollRect();
        RefreshNow(true);
        nextRefreshAt = Time.unscaledTime + refreshInterval;
    }

    private void OnDisable()
    {
        if (nameTooltip != null)
            nameTooltip.Hide();
    }

    private void Update()
    {
        if (Time.unscaledTime < nextRefreshAt)
            return;

        nextRefreshAt = Time.unscaledTime + refreshInterval;
        RefreshNow(false);
    }

    /// <summary>
    /// ���� �߰� ���¸� ��� �ٽ� �о� ����� �����մϴ�.
    /// </summary>
    public void RefreshNow(bool forceRebuild = false)
    {
        ResolveReferences();
        ConfigureScrollRect();

        DataManager dataManager = GetDataManager();
        if (dataManager == null || dataManager.CompoundDatabase == null || contentRoot == null || recipeSlotPrefab == null)
            return;

        RecordDiscoveryService.BackfillFromCurrentState(dataManager);

        List<CompoundData> visibleRecipes = dataManager.CompoundDatabase.GetAll()
            .Where(compound => compound != null)
            .Where(compound => HasAnyDiscoveredMaterial(dataManager, compound))
            .OrderBy(compound => GetTrailingNumber(compound.CompoundId))
            .ThenBy(compound => compound.CompoundId, StringComparer.OrdinalIgnoreCase)
            .ToList();

        string stateKey = BuildStateKey(dataManager, visibleRecipes);
        if (!forceRebuild && string.Equals(lastStateKey, stateKey, StringComparison.Ordinal))
            return;

        lastStateKey = stateKey;
        Rebuild(dataManager, visibleRecipes);
    }

    private void Rebuild(DataManager dataManager, List<CompoundData> visibleRecipes)
    {
        ClearSpawnedSlots();

        if (nameTooltip != null)
            nameTooltip.Hide();

        for (int i = 0; i < visibleRecipes.Count; i++)
        {
            CompoundData compound = visibleRecipes[i];
            CompoundRecipeSlotUI slot = Instantiate(recipeSlotPrefab, contentRoot, false);
            slot.gameObject.SetActive(true);
            slot.Bind(dataManager, compound, nameTooltip);
            spawnedSlots.Add(slot);
        }

        RefreshContentLayout();
    }

    /// <summary>
    /// �������� ������ ������ Preferred Height�� ��� Content�� �ݿ��մϴ�.
    /// ScrollRect�� Clamped�� Content Bounds�� Viewport���� Ŀ�� ������ �� �����Ƿ�,
    /// ���̾ƿ� ������ �ʾ��� Content�� �۰� ���Ǵ� ������ ���⼭ �ٷ� �����մϴ�.
    /// </summary>
    private void RefreshContentLayout()
    {
        if (contentRoot == null)
            return;

        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(contentRoot);

        float preferredHeight = LayoutUtility.GetPreferredHeight(contentRoot);
        if (preferredHeight > 0f)
            contentRoot.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, preferredHeight);

        LayoutRebuilder.ForceRebuildLayoutImmediate(contentRoot);
        Canvas.ForceUpdateCanvases();

        if (scrollRect != null)
        {
            scrollRect.content = contentRoot;
            scrollRect.StopMovement();
            scrollRect.SetLayoutVertical();
        }
    }

    private void ConfigureScrollRect()
    {
        if (scrollRect == null)
            return;

        if (contentRoot != null)
            scrollRect.content = contentRoot;

        scrollRect.vertical = true;

        if (forceClampedMovement)
            scrollRect.movementType = ScrollRect.MovementType.Clamped;
    }

    private static bool HasAnyDiscoveredMaterial(DataManager dataManager, CompoundData compound)
    {
        if (compound == null)
            return false;

        return IsItemDiscovered(dataManager, compound.MaterialId1)
            || IsItemDiscovered(dataManager, compound.MaterialId2)
            || IsItemDiscovered(dataManager, compound.MaterialId3);
    }

    private static bool IsItemDiscovered(DataManager dataManager, string itemId)
    {
        return !string.IsNullOrWhiteSpace(itemId)
            && RecordDiscoveryService.IsItemDiscovered(dataManager, itemId.Trim());
    }

    private static string BuildStateKey(DataManager dataManager, List<CompoundData> recipes)
    {
        var parts = new List<string>(recipes.Count * 5);

        for (int i = 0; i < recipes.Count; i++)
        {
            CompoundData compound = recipes[i];
            parts.Add(compound.CompoundId ?? string.Empty);
            parts.Add(IsItemDiscovered(dataManager, compound.MaterialId1) ? "1" : "0");
            parts.Add(IsItemDiscovered(dataManager, compound.MaterialId2) ? "1" : "0");
            parts.Add(IsItemDiscovered(dataManager, compound.MaterialId3) ? "1" : "0");
            parts.Add(RecordDiscoveryService.IsCompoundDiscovered(dataManager, compound.CompoundId) ? "1" : "0");
        }

        return string.Join("|", parts);
    }

    private void ClearSpawnedSlots()
    {
        for (int i = 0; i < spawnedSlots.Count; i++)
        {
            if (spawnedSlots[i] != null)
            {
                spawnedSlots[i].gameObject.SetActive(false);
                Destroy(spawnedSlots[i].gameObject);
            }
        }

        spawnedSlots.Clear();
    }

    private void ResolveReferences()
    {
        if (contentRoot == null)
        {
            Transform content = transform.Find("Scroll View/Viewport/Content");
            if (content == null)
                content = FindDeepChild(transform, "Content");

            contentRoot = content as RectTransform;
        }

        if (scrollRect == null)
        {
            Transform scrollView = transform.Find("Scroll View");
            if (scrollView != null)
                scrollRect = scrollView.GetComponent<ScrollRect>();

            if (scrollRect == null && contentRoot != null)
                scrollRect = contentRoot.GetComponentInParent<ScrollRect>();
        }

        if (nameTooltip == null)
        {
            Transform nameInfo = FindDeepChild(transform, "Nameinfo");
            if (nameInfo != null)
            {
                nameTooltip = nameInfo.GetComponent<CompoundReferenceNameTooltip>();
                if (nameTooltip == null)
                    nameTooltip = nameInfo.gameObject.AddComponent<CompoundReferenceNameTooltip>();
            }
        }

        // Content �ȿ� �̸� ��ġ�� �� CompoundRecipeSlot�� ������ ���ø�ó�� ����� ���� �ֽ��ϴ�.
        if (recipeSlotPrefab == null && contentRoot != null)
        {
            CompoundRecipeSlotUI[] slots = contentRoot.GetComponentsInChildren<CompoundRecipeSlotUI>(true);
            if (slots.Length > 0)
                recipeSlotPrefab = slots[0];
        }
    }

    private void HideSceneTemplateIfNeeded()
    {
        if (recipeSlotPrefab == null || contentRoot == null)
            return;

        if (recipeSlotPrefab.transform.parent == contentRoot)
            recipeSlotPrefab.gameObject.SetActive(false);
    }

    private static DataManager GetDataManager()
    {
        if (DataManager.Instance != null)
            return DataManager.Instance;

        return FindFirstObjectByType<DataManager>(FindObjectsInactive.Include);
    }

    private static int GetTrailingNumber(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return int.MaxValue;

        int index = id.Length - 1;
        while (index >= 0 && char.IsDigit(id[index]))
            index--;

        string number = id.Substring(index + 1);
        return int.TryParse(number, out int parsed) ? parsed : int.MaxValue;
    }

    private static Transform FindDeepChild(Transform root, string childName)
    {
        if (root == null)
            return null;

        for (int i = 0; i < root.childCount; i++)
        {
            Transform child = root.GetChild(i);
            if (string.Equals(child.name, childName, StringComparison.Ordinal))
                return child;

            Transform found = FindDeepChild(child, childName);
            if (found != null)
                return found;
        }

        return null;
    }
}
