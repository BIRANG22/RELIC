using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIFadeInOnEnable : MonoBehaviour
{
    [Header("���̵� ����")]
    [Tooltip("���İ��� 0���� ���� ������ �ö󰡴� �� �ɸ��� �ð�")]
    [SerializeField] private float fadeDuration = 0.5f;

    [Header("���� ����")]
    [Tooltip("���̵� ȿ������ ������ �ڽ� ������Ʈ�Դϴ�. �ش� ������Ʈ�� ��� �ڽĵ� �Բ� ���ܵ˴ϴ�.")]
    [SerializeField] private List<GameObject> excludedObjects = new List<GameObject>();

    private class GraphicFadeData
    {
        public Graphic graphic;
        public float originalAlpha;
    }

    private readonly List<GraphicFadeData> fadeTargets = new List<GraphicFadeData>();

    private Coroutine fadeCoroutine;
    private Action fadeOutCompletedCallback;
    private CanvasGroup interactionCanvasGroup;
    private bool addedInteractionCanvasGroup;
    private bool capturedInteractionCanvasGroupState;
    private bool originalInteractable;
    private bool originalBlocksRaycasts;

    private bool initialized = false;

    private void Awake()
    {
        Initialize();
    }

    private void OnEnable()
    {
        if (!initialized)
        {
            Initialize();
        }

        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        fadeOutCompletedCallback = null;
        RestoreInteractionState();
        SetAlphaToZero();

        fadeCoroutine = StartCoroutine(FadeIn());
    }

    private void OnDisable()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
            fadeCoroutine = null;
        }

        fadeOutCompletedCallback = null;
        RestoreInteractionState();
        RestoreOriginalAlpha();
    }

    public bool TryFadeOutAndDeactivate(Action completedCallback = null)
    {
        if (!isActiveAndEnabled || !gameObject.activeInHierarchy)
            return false;

        if (!initialized)
            Initialize();

        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
            fadeCoroutine = null;
        }

        fadeOutCompletedCallback = completedCallback;
        BlockInteraction();
        fadeCoroutine = StartCoroutine(FadeOutAndDeactivate());
        return true;
    }

    /// <summary>
    /// ���� ������Ʈ�� ��� �ڽ��� Graphic�� ã��
    /// ���̵� ��� ����� �����մϴ�.
    /// </summary>
    private void Initialize()
    {
        fadeTargets.Clear();

        Graphic[] graphics = GetComponentsInChildren<Graphic>(true);

        foreach (Graphic graphic in graphics)
        {
            if (graphic == null)
            {
                continue;
            }

            // ���� ��� ���ԵǾ� ������ ���̵� ��󿡼� ����
            if (IsExcluded(graphic.transform))
            {
                continue;
            }

            GraphicFadeData data = new GraphicFadeData
            {
                graphic = graphic,
                originalAlpha = graphic.color.a
            };

            fadeTargets.Add(data);
        }

        initialized = true;
    }

    /// <summary>
    /// �ش� Transform�� ���� ������Ʈ �Ǵ�
    /// ���� ������Ʈ�� �ڽ����� Ȯ���մϴ�.
    /// </summary>
    private bool IsExcluded(Transform target)
    {
        if (target != null && target.GetComponentInParent<UIBlurBackground>(true) != null)
            return true;

        foreach (GameObject excludedObject in excludedObjects)
        {
            if (excludedObject == null)
            {
                continue;
            }

            Transform excludedTransform = excludedObject.transform;

            // ���� ������Ʈ �ڱ� �ڽ�
            if (target == excludedTransform)
            {
                return true;
            }

            // ���� ������Ʈ�� �ڽ�
            if (target.IsChildOf(excludedTransform))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// ���̵� ������ ���İ��� 0���� ����ϴ�.
    /// </summary>
    private void SetAlphaToZero()
    {
        foreach (GraphicFadeData data in fadeTargets)
        {
            if (data.graphic == null)
            {
                continue;
            }

            Color color = data.graphic.color;
            color.a = 0f;
            data.graphic.color = color;
        }
    }

    /// <summary>
    /// ���İ��� ���� ������ ������ �����մϴ�.
    /// </summary>
    private IEnumerator FadeIn()
    {
        if (fadeDuration <= 0f)
        {
            RestoreOriginalAlpha();
            fadeCoroutine = null;
            yield break;
        }

        float elapsedTime = 0f;

        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.unscaledDeltaTime;

            float t = Mathf.Clamp01(elapsedTime / fadeDuration);

            // ���۰� ���� �ڿ��������� ó��
            t = Mathf.SmoothStep(0f, 1f, t);

            foreach (GraphicFadeData data in fadeTargets)
            {
                if (data.graphic == null)
                {
                    continue;
                }

                Color color = data.graphic.color;

                // ���� ������ �ִ� ���İ������� ����
                color.a = Mathf.Lerp(0f, data.originalAlpha, t);

                data.graphic.color = color;
            }

            yield return null;
        }

        RestoreOriginalAlpha();

        fadeCoroutine = null;
    }

    private IEnumerator FadeOutAndDeactivate()
    {
        List<float> startAlphas = CaptureCurrentAlphas();

        if (fadeDuration <= 0f)
        {
            SetAlphaToZero();
            CompleteFadeOutAndDeactivate();
            yield break;
        }

        float elapsedTime = 0f;

        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.unscaledDeltaTime;

            float t = Mathf.Clamp01(elapsedTime / fadeDuration);
            t = Mathf.SmoothStep(0f, 1f, t);

            for (int i = 0; i < fadeTargets.Count; i++)
            {
                GraphicFadeData data = fadeTargets[i];
                if (data.graphic == null)
                    continue;

                Color color = data.graphic.color;
                float startAlpha = i < startAlphas.Count ? startAlphas[i] : color.a;
                color.a = Mathf.Lerp(startAlpha, 0f, t);
                data.graphic.color = color;
            }

            yield return null;
        }

        SetAlphaToZero();
        CompleteFadeOutAndDeactivate();
    }

    private List<float> CaptureCurrentAlphas()
    {
        List<float> startAlphas = new List<float>(fadeTargets.Count);
        for (int i = 0; i < fadeTargets.Count; i++)
        {
            Graphic graphic = fadeTargets[i].graphic;
            startAlphas.Add(graphic != null ? graphic.color.a : 0f);
        }

        return startAlphas;
    }

    private void CompleteFadeOutAndDeactivate()
    {
        Action callback = fadeOutCompletedCallback;
        fadeOutCompletedCallback = null;
        fadeCoroutine = null;

        gameObject.SetActive(false);
        callback?.Invoke();
    }

    private void BlockInteraction()
    {
        EnsureInteractionCanvasGroup();

        if (interactionCanvasGroup == null)
            return;

        interactionCanvasGroup.interactable = false;
        interactionCanvasGroup.blocksRaycasts = false;
    }

    private void EnsureInteractionCanvasGroup()
    {
        if (interactionCanvasGroup != null)
            return;

        interactionCanvasGroup = GetComponent<CanvasGroup>();
        addedInteractionCanvasGroup = interactionCanvasGroup == null;

        if (interactionCanvasGroup == null)
            interactionCanvasGroup = gameObject.AddComponent<CanvasGroup>();

        if (interactionCanvasGroup == null || capturedInteractionCanvasGroupState)
            return;

        originalInteractable = interactionCanvasGroup.interactable;
        originalBlocksRaycasts = interactionCanvasGroup.blocksRaycasts;
        capturedInteractionCanvasGroupState = true;
    }

    private void RestoreInteractionState()
    {
        if (interactionCanvasGroup != null && capturedInteractionCanvasGroupState)
        {
            interactionCanvasGroup.interactable = originalInteractable;
            interactionCanvasGroup.blocksRaycasts = originalBlocksRaycasts;
        }

        if (addedInteractionCanvasGroup && interactionCanvasGroup != null)
        {
            if (Application.isPlaying)
                Destroy(interactionCanvasGroup);
            else
                DestroyImmediate(interactionCanvasGroup);
        }

        interactionCanvasGroup = null;
        addedInteractionCanvasGroup = false;
        capturedInteractionCanvasGroupState = false;
    }

    /// <summary>
    /// ��� ���̵� ����� ���� ���İ��� �����մϴ�.
    /// </summary>
    private void RestoreOriginalAlpha()
    {
        foreach (GraphicFadeData data in fadeTargets)
        {
            if (data.graphic == null)
            {
                continue;
            }

            Color color = data.graphic.color;
            color.a = data.originalAlpha;
            data.graphic.color = color;
        }
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        // �ν����Ϳ��� ���� ����� ������ ���
        // �÷��� �� �ٽ� ����� �����ϵ��� �մϴ�.
        initialized = false;
    }
#endif
}