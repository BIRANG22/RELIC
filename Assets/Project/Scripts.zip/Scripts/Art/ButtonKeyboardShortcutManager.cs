using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class ButtonKeyboardShortcutManager : MonoBehaviour
{
    [Serializable]
    public class ButtonShortcut
    {
        [Tooltip("Ű���� �Է����� ������ UI ��ư")]
        public Button targetButton;

        [Tooltip("��ư�� ������ Ű")]
        public Key shortcutKey = Key.Enter;

        [Tooltip("��ư�� ��Ȱ��ȭ�Ǿ� �ְų� ��ȣ�ۿ� �Ұ����ϸ� �������� ����")]
        public bool checkInteractable = true;
    }

    [Header("��ư ����Ű ���")]
    [SerializeField]
    private List<ButtonShortcut> buttonShortcuts = new List<ButtonShortcut>();

    private void Update()
    {
        if (Keyboard.current == null)
            return;

        foreach (ButtonShortcut shortcut in buttonShortcuts)
        {
            if (shortcut == null || shortcut.targetButton == null)
                continue;

            if (!Keyboard.current[shortcut.shortcutKey].wasPressedThisFrame)
                continue;

            if (!CanExecute(shortcut))
                continue;

            shortcut.targetButton.onClick.Invoke();
        }
    }

    private bool CanExecute(ButtonShortcut shortcut)
    {
        Button button = shortcut.targetButton;

        if (!button.gameObject.activeInHierarchy)
            return false;

        if (shortcut.checkInteractable && !button.interactable)
            return false;

        return true;
    }
}