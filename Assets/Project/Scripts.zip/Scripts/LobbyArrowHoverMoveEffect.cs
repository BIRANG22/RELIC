using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// �κ��� ����/���� ȭ��ǥ ��ư�� ���콺�� �÷��� ��
/// ������ ȭ��ǥ �̹����� �¿�� õõ�� �ݺ� �̵���ŵ�ϴ�.
/// </summary>
public class LobbyArrowHoverMoveEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public enum MoveDirection
    {
        Left = -1,
        Right = 1
    }

    [Header("Move Target")]
    [Tooltip("������ ������ ȭ��ǥ �̹����� RectTransform�Դϴ�. ��ư ��ü�� �ƴ� �ڽ� �̹����� �����ϴ� ���� �����մϴ�.")]
    [SerializeField] private RectTransform moveTarget;

    [Header("Hover Move")]
    [Tooltip("���� ��ư�� Left, ���� ��ư�� Right�� �����մϴ�.")]
    [SerializeField] private MoveDirection moveDirection = MoveDirection.Right;

    [Tooltip("���� ��ġ���� �̵��� �ִ� �Ÿ��Դϴ�.")]
    [SerializeField, Min(0f)] private float moveDistance = 10f;

    [Tooltip("���� ��ġ���� �̵��� �� �ٽ� ���ƿ�������� �� �� �պ� �ð��Դϴ�.")]
    [SerializeField, Min(0.01f)] private float roundTripDuration = 0.8f;

    [Tooltip("���콺�� ������ �� ���� ��ġ�� ���ƿ��� �ð��Դϴ�.")]
    [SerializeField, Min(0.01f)] private float returnDuration = 0.15f;

    private Vector2 originalAnchoredPosition;
    private Coroutine moveRoutine;
    private bool isPointerInside;
    private bool hasCachedOriginalPosition;

    private RectTransform Target
    {
        get
        {
            if (moveTarget == null)
                moveTarget = transform as RectTransform;

            return moveTarget;
        }
    }

    private void Awake()
    {
        CacheOriginalPosition();
    }

    private void OnEnable()
    {
        CacheOriginalPosition();
        ResetPositionImmediate();
    }

    private void OnDisable()
    {
        StopMoveRoutine();
        isPointerInside = false;
        ResetPositionImmediate();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isPointerInside = true;
        StartMoveRoutine();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isPointerInside = false;
        StartMoveRoutine();
    }

    private void CacheOriginalPosition()
    {
        RectTransform target = Target;

        if (target == null)
            return;

        originalAnchoredPosition = target.anchoredPosition;
        hasCachedOriginalPosition = true;
    }

    private void StartMoveRoutine()
    {
        StopMoveRoutine();

        if (!gameObject.activeInHierarchy || Target == null)
            return;

        if (!hasCachedOriginalPosition)
            CacheOriginalPosition();

        moveRoutine = StartCoroutine(MoveRoutine());
    }

    private IEnumerator MoveRoutine()
    {
        RectTransform target = Target;

        if (target == null)
            yield break;

        float phase = 0f;
        float safeRoundTripDuration = Mathf.Max(0.01f, roundTripDuration);
        float direction = (float)moveDirection;

        while (isPointerInside)
        {
            phase += Time.unscaledDeltaTime * Mathf.PI / safeRoundTripDuration;

            if (phase >= Mathf.PI)
                phase -= Mathf.PI;

            float offset = Mathf.Sin(phase) * moveDistance * direction;
            target.anchoredPosition = originalAnchoredPosition + new Vector2(offset, 0f);
            yield return null;
        }

        Vector2 startPosition = target.anchoredPosition;
        float safeReturnDuration = Mathf.Max(0.01f, returnDuration);
        float elapsed = 0f;

        while (elapsed < safeReturnDuration && !isPointerInside)
        {
            elapsed += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(elapsed / safeReturnDuration);
            t = t * t * (3f - 2f * t);
            target.anchoredPosition = Vector2.LerpUnclamped(startPosition, originalAnchoredPosition, t);
            yield return null;
        }

        if (!isPointerInside)
            target.anchoredPosition = originalAnchoredPosition;

        moveRoutine = null;
    }

    private void StopMoveRoutine()
    {
        if (moveRoutine == null)
            return;

        StopCoroutine(moveRoutine);
        moveRoutine = null;
    }

    private void ResetPositionImmediate()
    {
        RectTransform target = Target;

        if (target != null && hasCachedOriginalPosition)
            target.anchoredPosition = originalAnchoredPosition;
    }
}
