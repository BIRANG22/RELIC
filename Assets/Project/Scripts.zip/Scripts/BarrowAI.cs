using Relic.Gameplay.Battle;
using Relic.Gameplay.Data;
using System.Collections.Generic;
using UnityEngine;

namespace Relic.Gameplay.Monster
{
    /// <summary>
    /// �ٷο� AI
    /// - �ൿ ����: MonsterMasterData�� AttackRange(Range_20)
    /// - �̵�: ����� ĳ���Ͱ� �ൿ ���� �ȿ� ������ ��/��/��/��� ��Ȯ�� 2ĭ �Ÿ��� �����ϴ�.
    /// - ����: ���� ���� ���ο� ĳ���Ͱ� ������ ���� ���������� �����մϴ�.
    /// - ���: ���� ���� ���ο� ĳ���Ͱ� ������ ���� �� ĳ������ ���� ���� ��ġ�� �ֺ� 8ĭ�� �����մϴ�.
    /// </summary>
    public class BarrowAI : MonsterAIBase
    {
        private const string MoveSkillId = "S_Monster_29";
        private const string DirectShotSkillId = "S_Monster_30";
        private const string ArcShotSkillId = "S_Monster_31";

        private static readonly Vector2Int[] EscapeOffsets =
        {
            new Vector2Int(2, 0),
            new Vector2Int(-2, 0),
            new Vector2Int(0, 2),
            new Vector2Int(0, -2)
        };

        public override string SelectSkill(MonsterRuntimeData monster, BattleContext context)
        {
            return DirectShotSkillId;
        }

        public override MonsterAIPlan CreatePlan(
            MonsterUnit monsterUnit,
            BattleContext context,
            GridManager gridManager)
        {
            MonsterAIPlan plan = new();

            if (monsterUnit == null || monsterUnit.RuntimeData == null || gridManager == null)
                return plan;

            const int group = 1;
            Vector2Int moveOffset = Vector2Int.zero;

            int nearbyTargetGridIndex = FindNearestCharacterTargetInActionRange(monsterUnit, gridManager);

            // ĳ���Ͱ� Range_20 ������ �������� ���� �Ÿ��� �����ϴ�.
            if (nearbyTargetGridIndex >= 0)
            {
                moveOffset = GetBestEscapeMove(
                    monsterUnit,
                    gridManager);

                if (moveOffset != Vector2Int.zero)
                {
                    plan.Add(new MonsterAIAction(
                        MoveSkillId,
                        moveOffset,
                        MonsterAISlotPreference.Front,
                        group,
                        0));
                }
            }

            int projectedGridIndex = GetExpectedEscapeGridIndex(
                monsterUnit,
                gridManager,
                moveOffset);

            // ��/�Ϸ� �ٸ� �������� ����ģ ��쿡�� ����� �ٽ� ��ȯ���� �ʰ� ��縦 ����մϴ�.
            // ���ڸ� �Ǵ� ��/�� ������ ��쿡�� ���� ���� ������ ĳ���͸� ã�� ���縦 �����մϴ�.
            bool escapedToDifferentLine = moveOffset.y != 0;

            if (!escapedToDifferentLine &&
                TryBuildDirectShot(
                    projectedGridIndex,
                    gridManager,
                    out BattleDirection directDirection,
                    out List<int> directRange))
            {
                // �̵� ���� ���縸 ������ ���� ���� ������ ��ǥ ������ �ٶ󺸰� �մϴ�.
                // ���� �ǰ� ������ Facing�� �ٲ�� ���� ������ ���� Facing�� ����մϴ�.
                if (moveOffset == Vector2Int.zero)
                    SetFacingForReservedAttack(monsterUnit, directDirection);

                plan.Add(new MonsterAIAction(
                    DirectShotSkillId,
                    Vector2Int.zero,
                    moveOffset != Vector2Int.zero
                        ? MonsterAISlotPreference.SameSlot
                        : MonsterAISlotPreference.Front,
                    group,
                    1,
                    projectedGridIndex,
                    moveOffset != Vector2Int.zero,
                    directDirection,
                    false,
                    0,
                    directRange));

                return plan;
            }

            // ���� ���� ���ο� ĳ���Ͱ� ���ٸ� ���� �� ĳ������ ���� �׸��带 �߽����� ��縦 �����մϴ�.
            BattleCharacter farthestPlayer = FindFarthestPlayerFromGrid(projectedGridIndex, gridManager);

            if (farthestPlayer == null || farthestPlayer.CurrentGridIndex < 0)
                return plan;

            List<int> arcRange = BuildThreeByThreeRange(
                farthestPlayer.CurrentGridIndex,
                gridManager);

            if (arcRange.Count <= 0)
                return plan;

            plan.Add(new MonsterAIAction(
                ArcShotSkillId,
                Vector2Int.zero,
                moveOffset != Vector2Int.zero
                    ? MonsterAISlotPreference.SameSlot
                    : MonsterAISlotPreference.Front,
                group,
                1,
                projectedGridIndex,
                false,
                BattleDirection.Right,
                false,
                0,
                arcRange));

            return plan;
        }

        private int FindNearestCharacterTargetInActionRange(
            MonsterUnit monsterUnit,
            GridManager gridManager)
        {
            if (monsterUnit == null ||
                monsterUnit.RuntimeData == null ||
                gridManager == null ||
                monsterUnit.MainGridIndex < 0)
            {
                return -1;
            }

            string actionRangeId = monsterUnit.RuntimeData.AttackRangeId;

            if (string.IsNullOrWhiteSpace(actionRangeId) || actionRangeId.Trim() == "0")
                return -1;

            RangeDatabase rangeDatabase = DataManager.Instance?.RangeDatabase;

            if (rangeDatabase == null)
                return -1;

            List<int> actionRange = BattleRangeCalculator.GetSelectionRangeIndices(
                monsterUnit.MainGridIndex,
                actionRangeId,
                rangeDatabase,
                gridManager);

            if (actionRange == null || actionRange.Count <= 0)
                return -1;

            HashSet<int> actionRangeSet = new(actionRange);
            BattleCharacter[] players = FindPlayers();
            Vector2Int monsterCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);

            int nearestGridIndex = -1;
            int nearestDistance = int.MaxValue;

            for (int i = 0; i < players.Length; i++)
            {
                BattleCharacter player = players[i];

                if (!IsAlivePlayer(player) || player.CurrentGridIndex < 0)
                    continue;

                if (!actionRangeSet.Contains(player.CurrentGridIndex))
                    continue;

                Vector2Int playerCoord = gridManager.IndexToCoord(player.CurrentGridIndex);
                int distance =
                    Mathf.Abs(playerCoord.x - monsterCoord.x) +
                    Mathf.Abs(playerCoord.y - monsterCoord.y);

                if (distance >= nearestDistance)
                    continue;

                nearestDistance = distance;
                nearestGridIndex = player.CurrentGridIndex;
            }

            return nearestGridIndex;
        }

        private Vector2Int GetBestEscapeMove(
            MonsterUnit monsterUnit,
            GridManager gridManager)
        {
            if (monsterUnit == null || gridManager == null)
                return Vector2Int.zero;

            BattleCharacter[] players = FindPlayers();
            Vector2Int currentCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);

            Vector2Int bestOffset = Vector2Int.zero;
            bool bestIsHorizontal = false;
            int bestMinDistance = int.MinValue;
            int bestTotalDistance = int.MinValue;

            Vector2Int bestCollisionOffset = Vector2Int.zero;
            bool bestCollisionIsHorizontal = false;
            int bestCollisionMinDistance = int.MinValue;
            int bestCollisionTotalDistance = int.MinValue;

            for (int i = 0; i < EscapeOffsets.Length; i++)
            {
                Vector2Int offset = EscapeOffsets[i];

                if (!CanReserveTwoTileEscape(
                        monsterUnit,
                        gridManager,
                        offset,
                        out bool secondCellStopsEarly))
                {
                    continue;
                }

                Vector2Int step = new(
                    offset.x == 0 ? 0 : (offset.x > 0 ? 1 : -1),
                    offset.y == 0 ? 0 : (offset.y > 0 ? 1 : -1));
                Vector2Int movedCoord = secondCellStopsEarly
                    ? currentCoord + step
                    : currentCoord + offset;
                bool isHorizontal = offset.y == 0;
                bool candidateGetsCloserToAnyPlayer = false;
                int candidateMinDistance = int.MaxValue;
                int candidateTotalDistance = 0;
                int alivePlayerCount = 0;

                for (int playerIndex = 0; playerIndex < players.Length; playerIndex++)
                {
                    BattleCharacter player = players[playerIndex];

                    if (!IsAlivePlayer(player) || player.CurrentGridIndex < 0)
                        continue;

                    alivePlayerCount++;
                    Vector2Int playerCoord = gridManager.IndexToCoord(player.CurrentGridIndex);

                    int currentDistance =
                        Mathf.Abs(playerCoord.x - currentCoord.x) +
                        Mathf.Abs(playerCoord.y - currentCoord.y);
                    int candidateDistance =
                        Mathf.Abs(playerCoord.x - movedCoord.x) +
                        Mathf.Abs(playerCoord.y - movedCoord.y);

                    // ������ ��� �ִ� ������ ��� ĳ���Ϳ��Ե� ��������� �ʴ� ������ �켱�մϴ�.
                    // �� ��° ĭ �浹 �ĺ��� ��ü �Ÿ� ������ ������ ����ؾ� �մϴ�.
                    if (candidateDistance < currentDistance)
                        candidateGetsCloserToAnyPlayer = true;

                    candidateMinDistance = Mathf.Min(candidateMinDistance, candidateDistance);
                    candidateTotalDistance += candidateDistance;
                }

                if (alivePlayerCount <= 0)
                    continue;

                // �� ��° ĭ�� ������ �ִ� 2ĭ ������ ù ĭ���� �̵��� �� �浹�ϴ�
                // ��� Ż�� �ĺ��� ����ϴ�. ������ ��� �ִ� ������ ������ ������
                // �װ��� �켱�ϰ�, ���� ���� �� �ĺ��� ����մϴ�.
                if (secondCellStopsEarly)
                {
                    bool collisionBetter =
                        (isHorizontal && !bestCollisionIsHorizontal) ||
                        (isHorizontal == bestCollisionIsHorizontal && candidateMinDistance > bestCollisionMinDistance) ||
                        (isHorizontal == bestCollisionIsHorizontal &&
                         candidateMinDistance == bestCollisionMinDistance &&
                         candidateTotalDistance > bestCollisionTotalDistance);

                    if (collisionBetter)
                    {
                        bestCollisionIsHorizontal = isHorizontal;
                        bestCollisionMinDistance = candidateMinDistance;
                        bestCollisionTotalDistance = candidateTotalDistance;
                        bestCollisionOffset = offset;
                    }

                    continue;
                }

                // ������ ��� �ִ� ���������� ��� ĳ���Ϳ��Ե� ��������� �ʴ� �ĺ��� ����մϴ�.
                if (candidateGetsCloserToAnyPlayer)
                    continue;

                // ���縦 ������ �� �ֵ��� ��/�� 2ĭ ������ �ֿ켱���� �մϴ�.
                // ���� �� �ĺ������� ���� ����� ĳ���Ϳ��� �Ÿ��� ���� ������,
                // �����̸� ��� ĳ���Ϳ��� �ѰŸ��� �� ū ������ �����մϴ�.
                bool better =
                    (isHorizontal && !bestIsHorizontal) ||
                    (isHorizontal == bestIsHorizontal && candidateMinDistance > bestMinDistance) ||
                    (isHorizontal == bestIsHorizontal &&
                     candidateMinDistance == bestMinDistance &&
                     candidateTotalDistance > bestTotalDistance);

                if (!better)
                    continue;

                bestIsHorizontal = isHorizontal;
                bestMinDistance = candidateMinDistance;
                bestTotalDistance = candidateTotalDistance;
                bestOffset = offset;
            }

            if (bestOffset != Vector2Int.zero)
                return bestOffset;

            return bestCollisionOffset;
        }

        private bool CanReserveTwoTileEscape(
            MonsterUnit monsterUnit,
            GridManager gridManager,
            Vector2Int moveOffset,
            out bool secondCellStopsEarly)
        {
            secondCellStopsEarly = false;

            if (monsterUnit == null || gridManager == null)
                return false;

            bool horizontal = moveOffset.y == 0 && Mathf.Abs(moveOffset.x) == 2;
            bool vertical = moveOffset.x == 0 && Mathf.Abs(moveOffset.y) == 2;

            if (!horizontal && !vertical)
                return false;

            Vector2Int currentCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);
            Vector2Int step = new(
                moveOffset.x == 0 ? 0 : (moveOffset.x > 0 ? 1 : -1),
                moveOffset.y == 0 ? 0 : (moveOffset.y > 0 ? 1 : -1));

            Vector2Int firstCoord = currentCoord + step;
            Vector2Int secondCoord = firstCoord + step;

            if (!gridManager.IsValidCoord(firstCoord))
                return false;

            int firstTargetIndex = gridManager.CoordToIndex(firstCoord);

            // ù ĭ�� ���� ������ ��� ��ü�� �� �� �����Ƿ� �ĺ����� �����մϴ�.
            if (BattleOccupancyService.IsOccupiedByAnyUnit(firstTargetIndex, null, monsterUnit))
                return false;

            BattleGridEffectController gridEffectController =
                Object.FindFirstObjectByType<BattleGridEffectController>(FindObjectsInactive.Include);

            if (gridEffectController != null && gridEffectController.IsBlocked(firstTargetIndex))
                return false;

            // �� ��° ĭ�� �� ���̸� 2ĭ �̵� ��ü�� �����մϴ�.
            // ���� �� ù ��° ĭ���� �̵��� �� �� ��迡 ���� ����˴ϴ�.
            if (!gridManager.IsValidCoord(secondCoord))
            {
                secondCellStopsEarly = true;
                return true;
            }

            int secondTargetIndex = gridManager.CoordToIndex(secondCoord);

            // ����/���� ��ֹ��� ���� �ܰ迡�� ���մϴ�. �� ��° ĭ�� ���ָ�
            // ���� �� 1ĭ �̵� �� �浹�� �� �ֵ��� ����մϴ�.
            if (gridEffectController != null && gridEffectController.IsBlocked(secondTargetIndex))
                return false;

            secondCellStopsEarly =
                BattleOccupancyService.IsOccupiedByAnyUnit(secondTargetIndex, null, monsterUnit);

            return true;
        }

        private int GetExpectedEscapeGridIndex(
            MonsterUnit monsterUnit,
            GridManager gridManager,
            Vector2Int moveOffset)
        {
            if (monsterUnit == null || gridManager == null || monsterUnit.MainGridIndex < 0)
                return -1;

            if (moveOffset == Vector2Int.zero)
                return monsterUnit.MainGridIndex;

            Vector2Int currentCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);
            Vector2Int step = new(
                moveOffset.x == 0 ? 0 : (moveOffset.x > 0 ? 1 : -1),
                moveOffset.y == 0 ? 0 : (moveOffset.y > 0 ? 1 : -1));
            Vector2Int firstCoord = currentCoord + step;

            if (!gridManager.IsValidCoord(firstCoord))
                return monsterUnit.MainGridIndex;

            Vector2Int secondCoord = firstCoord + step;

            if (!gridManager.IsValidCoord(secondCoord))
                return gridManager.CoordToIndex(firstCoord);

            int secondTargetIndex = gridManager.CoordToIndex(secondCoord);
            bool secondCellOccupied =
                BattleOccupancyService.IsOccupiedByAnyUnit(secondTargetIndex, null, monsterUnit);

            return secondCellOccupied
                ? gridManager.CoordToIndex(firstCoord)
                : secondTargetIndex;
        }

        private bool TryBuildDirectShot(
            int originGridIndex,
            GridManager gridManager,
            out BattleDirection direction,
            out List<int> rangeGridIndices)
        {
            direction = BattleDirection.Right;
            rangeGridIndices = new List<int>();

            if (originGridIndex < 0 || gridManager == null)
                return false;

            BattleCharacter[] players = FindPlayers();
            Vector2Int origin = gridManager.IndexToCoord(originGridIndex);

            BattleCharacter bestTarget = null;
            int bestDistance = int.MaxValue;

            for (int i = 0; i < players.Length; i++)
            {
                BattleCharacter player = players[i];

                if (!IsAlivePlayer(player) || player.CurrentGridIndex < 0)
                    continue;

                Vector2Int playerCoord = gridManager.IndexToCoord(player.CurrentGridIndex);

                if (playerCoord.y != origin.y || playerCoord.x == origin.x)
                    continue;

                int distance = Mathf.Abs(playerCoord.x - origin.x);

                if (distance >= bestDistance)
                    continue;

                bestDistance = distance;
                bestTarget = player;
            }

            if (bestTarget == null)
                return false;

            Vector2Int targetCoord = gridManager.IndexToCoord(bestTarget.CurrentGridIndex);
            int horizontalSign = targetCoord.x > origin.x ? 1 : -1;

            direction = horizontalSign > 0
                ? BattleDirection.Right
                : BattleDirection.Left;

            rangeGridIndices = BuildHorizontalLineToGridEdge(
                originGridIndex,
                gridManager,
                horizontalSign);

            return rangeGridIndices.Count > 0;
        }


        private static void SetFacingForReservedAttack(
            MonsterUnit monsterUnit,
            BattleDirection direction)
        {
            if (monsterUnit == null)
                return;

            BattleUnitFacing facing = monsterUnit.GetComponent<BattleUnitFacing>();
            bool faceRight = direction == BattleDirection.Right;

            if (facing != null)
                facing.FaceRight(faceRight);

            if (monsterUnit.RuntimeData != null)
                monsterUnit.RuntimeData.Direction = direction;
        }

        private static List<int> BuildHorizontalLineToGridEdge(
            int originGridIndex,
            GridManager gridManager,
            int horizontalSign)
        {
            List<int> result = new();
            Vector2Int origin = gridManager.IndexToCoord(originGridIndex);
            int step = 1;

            while (true)
            {
                Vector2Int coord = origin + new Vector2Int(horizontalSign * step, 0);

                if (!gridManager.IsValidCoord(coord))
                    break;

                result.Add(gridManager.CoordToIndex(coord));
                step++;
            }

            return result;
        }

        private BattleCharacter FindFarthestPlayerFromGrid(
            int originGridIndex,
            GridManager gridManager)
        {
            if (originGridIndex < 0 || gridManager == null)
                return null;

            BattleCharacter[] players = FindPlayers();
            Vector2Int origin = gridManager.IndexToCoord(originGridIndex);

            BattleCharacter farthest = null;
            int farthestDistance = -1;

            for (int i = 0; i < players.Length; i++)
            {
                BattleCharacter player = players[i];

                if (!IsAlivePlayer(player) || player.CurrentGridIndex < 0)
                    continue;

                Vector2Int playerCoord = gridManager.IndexToCoord(player.CurrentGridIndex);
                int distance =
                    Mathf.Abs(playerCoord.x - origin.x) +
                    Mathf.Abs(playerCoord.y - origin.y);

                if (distance <= farthestDistance)
                    continue;

                farthestDistance = distance;
                farthest = player;
            }

            return farthest;
        }

        private static List<int> BuildThreeByThreeRange(
            int centerGridIndex,
            GridManager gridManager)
        {
            List<int> result = new();

            if (centerGridIndex < 0 || gridManager == null)
                return result;

            Vector2Int center = gridManager.IndexToCoord(centerGridIndex);

            for (int y = -1; y <= 1; y++)
            {
                for (int x = -1; x <= 1; x++)
                {
                    Vector2Int coord = center + new Vector2Int(x, y);

                    if (!gridManager.IsValidCoord(coord))
                        continue;

                    result.Add(gridManager.CoordToIndex(coord));
                }
            }

            return result;
        }
    }
}
