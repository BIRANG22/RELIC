using System.Collections.Generic;

namespace Relic.Gameplay.Data
{
    /// <summary>
    /// GameData�� Erosion ��Ʈ�� ErosionData ������� ��ȯ�մϴ�.
    /// </summary>
    public static class ErosionCsvLoader
    {
        public static List<ErosionData> Load(
            Dictionary<string, List<Dictionary<string, string>>> workbook)
        {
            return DataRowMapper.MapList<ErosionData>(
                ExcelSheetSelector.GetSheet(workbook, "Erosion")
            );
        }
    }
}
