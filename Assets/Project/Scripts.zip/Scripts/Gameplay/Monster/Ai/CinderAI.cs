using Relic.Gameplay.Battle;
using Relic.Gameplay.Data;
using System.Collections.Generic;
using UnityEngine;

namespace Relic.Gameplay.Monster
{
    /// <summary>
    /// �Ŵ� AI
    /// - �� �� �浹���� �ʴ� 8���� 1ĭ �̵� �ĺ� �� �����߷� ���� ���� ��� �ִ� ĳ���͸� ���� �� �ִ� ��ġ�� �����մϴ�.
    /// - ���� ���� ĳ���͸� ���� �� �ִٸ� ��� �ִ� ĳ���͵���� �ѰŸ��� �� ����� ��ġ�� �켱�մϴ�.
    /// - E_Explode ��ġ�� 0�� �� �Ͽ��� ���� �̵��� �� ���� ��ġ���� �������� ����մϴ�.
    /// </summary>
    public class CinderAI : MonsterAIBase
    {
        private const string MoveSkillId = "S_Monster_13";
        private const string ExplodeSkillId = "S_Monster_14";

        private static readonly Vector2Int[] MoveDirections =
        {
            Vector2Int.up,
            Vector2Int.down,
            Vector2Int.left,
            Vector2Int.right,
            new Vector2Int(-1, 1),
            new Vector2Int(1, 1),
            new Vector2Int(-1, -1),
            new Vector2Int(1, -1)
        };

        public override string SelectSkill(MonsterRuntimeData monster, BattleContext context)
        {
            return monster != null && monster.IsExplodeReady
                ? ExplodeSkillId
                : MoveSkillId;
        }

        public override MonsterAIPlan CreatePlan(
            MonsterUnit monsterUnit,
            BattleContext context,
            GridManager gridManager)
        {
            MonsterAIPlan plan = new();

            if (monsterUnit == null || monsterUnit.RuntimeData == null || gridManager == null)
                return plan;

            List<BattleCharacter> alivePlayers = GetAlivePlayers();
            HashSet<int> occupiedCharacterGridIndices = GetOccupiedCharacterGridIndices();

            if (alivePlayers.Count <= 0)
                return plan;

            MonsterSkillData explodeSkill =
                DataManager.Instance?.MonsterSkillDatabase?.Get(ExplodeSkillId);
            RangeDatabase rangeDatabase = DataManager.Instance?.RangeDatabase;
            string explodeRangeId = explodeSkill?.RangeId;

            if (string.IsNullOrWhiteSpace(explodeRangeId) || rangeDatabase == null)
                return plan;

            Vector2Int moveOffset = GetBestExplosionPositionMove(
                monsterUnit,
                gridManager,
                explodeRangeId,
                rangeDatabase,
                alivePlayers,
                occupiedCharacterGridIndices);

            int group = 1;
            int projectedGridIndex = monsterUnit.MainGridIndex;

            if (moveOffset != Vector2Int.zero)
            {
                plan.Add(new MonsterAIAction(
                    MoveSkillId,
                    moveOffset,
                    MonsterAISlotPreference.Front,
                    group,
                    0
                ));

                Vector2Int projectedCoord =
                    gridManager.IndexToCoord(monsterUnit.MainGridIndex) + moveOffset;

                if (gridManager.IsValidCoord(projectedCoord))
                    projectedGridIndex = gridManager.CoordToIndex(projectedCoord);
            }

            if (monsterUnit.RuntimeData.IsExplodeReady)
            {
                plan.Add(new MonsterAIAction(
                    ExplodeSkillId,
                    Vector2Int.zero,
                    moveOffset != Vector2Int.zero
                        ? MonsterAISlotPreference.SameSlot
                        : MonsterAISlotPreference.Front,
                    group,
                    moveOffset != Vector2Int.zero ? 1 : 0,
                    projectedGridIndex,
                    rangeOriginCasterGridIndex: projectedGridIndex
                ));
            }

            return plan;
        }

        private List<BattleCharacter> GetAlivePlayers()
        {
            List<BattleCharacter> result = new();
            BattleCharacter[] players = FindPlayers();

            for (int i = 0; i < players.Length; i++)
            {
                BattleCharacter player = players[i];

                if (!IsAlivePlayer(player) || player.CurrentGridIndex < 0)
                    continue;

                result.Add(player);
            }

            return result;
        }

        private HashSet<int> GetOccupiedCharacterGridIndices()
        {
            HashSet<int> result = new();
            BattleCharacter[] players = FindPlayers();

            for (int i = 0; i < players.Length; i++)
            {
                BattleCharacter player = players[i];

                if (player == null || player.CurrentGridIndex < 0)
                    continue;

                result.Add(player.CurrentGridIndex);
            }

            return result;
        }

        private Vector2Int GetBestExplosionPositionMove(
            MonsterUnit monsterUnit,
            GridManager gridManager,
            string explodeRangeId,
            RangeDatabase rangeDatabase,
            List<BattleCharacter> alivePlayers,
            HashSet<int> occupiedCharacterGridIndices)
        {
            if (monsterUnit == null ||
                monsterUnit.MainGridIndex < 0 ||
                gridManager == null ||
                alivePlayers == null ||
                alivePlayers.Count <= 0)
            {
                return Vector2Int.zero;
            }

            int currentGridIndex = monsterUnit.MainGridIndex;
            int bestTargetCount = int.MinValue;
            int bestDistanceScore = int.MaxValue;
            Vector2Int bestOffset = Vector2Int.zero;

            for (int i = 0; i < MoveDirections.Length; i++)
            {
                Vector2Int offset = MoveDirections[i];

                // ���� ������ �̹� ������ �����̳� ���ؿ� �浹�ϴ� �̵��� �������� �ʽ��ϴ�.
                if (!CanMonsterMove(monsterUnit, gridManager, offset))
                    continue;

                Vector2Int projectedCoord =
                    gridManager.IndexToCoord(currentGridIndex) + offset;

                // ���� �Ŵ� ��Ģ��� ���� ������ ũ�� �߸��� �� �����ڸ� ĭ�� �������� �ʽ��ϴ�.
                if (IsOuterGrid(projectedCoord, gridManager))
                    continue;

                int projectedGridIndex = gridManager.CoordToIndex(projectedCoord);

                // ���� Ÿ�� ���ο� ������, ���� ������ ĳ���Ͱ� �� �ִ� ĭ�� �̵� �ĺ����� �����մϴ�.
                // �����Ҵ� ĳ���͵� �׸��忡 ���� ���� ��ֹ��̹Ƿ� �����մϴ�.
                if (occupiedCharacterGridIndices != null &&
                    occupiedCharacterGridIndices.Contains(projectedGridIndex))
                {
                    continue;
                }

                int targetCount = GetExplosionTargetCount(
                    projectedGridIndex,
                    explodeRangeId,
                    rangeDatabase,
                    gridManager,
                    alivePlayers);
                int distanceScore = GetExplosionDistanceScore(
                    projectedGridIndex,
                    gridManager,
                    alivePlayers);

                if (targetCount < bestTargetCount)
                    continue;

                if (targetCount == bestTargetCount && distanceScore >= bestDistanceScore)
                    continue;

                bestTargetCount = targetCount;
                bestDistanceScore = distanceScore;
                bestOffset = offset;
            }

            return bestOffset;
        }

        private static int GetExplosionTargetCount(
            int originGridIndex,
            string explodeRangeId,
            RangeDatabase rangeDatabase,
            GridManager gridManager,
            List<BattleCharacter> alivePlayers)
        {
            List<int> rangeIndices = BattleRangeCalculator.GetSelectionRangeIndices(
                originGridIndex,
                explodeRangeId,
                rangeDatabase,
                gridManager);

            if (rangeIndices == null || rangeIndices.Count <= 0)
                return 0;

            HashSet<int> rangeSet = new(rangeIndices);
            int count = 0;

            for (int i = 0; i < alivePlayers.Count; i++)
            {
                BattleCharacter player = alivePlayers[i];

                if (player == null || player.CurrentGridIndex < 0)
                    continue;

                if (rangeSet.Contains(player.CurrentGridIndex))
                    count++;
            }

            return count;
        }

        private static int GetExplosionDistanceScore(
            int originGridIndex,
            GridManager gridManager,
            List<BattleCharacter> alivePlayers)
        {
            Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
            int totalDistance = 0;

            for (int i = 0; i < alivePlayers.Count; i++)
            {
                BattleCharacter player = alivePlayers[i];

                if (player == null || player.CurrentGridIndex < 0)
                    continue;

                Vector2Int playerCoord = gridManager.IndexToCoord(player.CurrentGridIndex);
                totalDistance +=
                    Mathf.Abs(playerCoord.x - originCoord.x) +
                    Mathf.Abs(playerCoord.y - originCoord.y);
            }

            return totalDistance;
        }

        private bool IsOuterGrid(Vector2Int coord, GridManager gridManager)
        {
            if (gridManager == null)
                return true;

            return coord.x <= 0 ||
                   coord.y <= 0 ||
                   coord.x >= gridManager.Width - 1 ||
                   coord.y >= gridManager.Height - 1;
        }
    }
}
