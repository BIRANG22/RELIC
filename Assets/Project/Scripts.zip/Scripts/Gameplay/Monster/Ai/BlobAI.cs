using Relic.Gameplay.Battle;
using Relic.Gameplay.Data;
using System.Collections.Generic;
using UnityEngine;

namespace Relic.Gameplay.Monster
{
    public class BlobAI : MonsterAIBase
    {
        private const string MoveSkillId = "S_Monster_03";
        private const string AttackSkillId = "S_Monster_04";
        private const string ResidueGridEffectId = "GR_Residue";

        private static readonly Vector2Int[] MoveDirections =
        {
            Vector2Int.up,
            Vector2Int.down,
            Vector2Int.left,
            Vector2Int.right
        };

        public override string SelectSkill(MonsterRuntimeData monster, BattleContext context)
        {
            return AttackSkillId;
        }

        public override MonsterAIPlan CreatePlan(
            MonsterUnit monsterUnit,
            BattleContext context,
            GridManager gridManager)
        {
            MonsterAIPlan plan = new();

            if (monsterUnit == null || monsterUnit.RuntimeData == null || gridManager == null)
                return plan;

            MonsterSkillData attackSkill =
                DataManager.Instance?.MonsterSkillDatabase?.Get(AttackSkillId);

            // ������ �ܼ��� ���� ����� ĳ���ͺ��� �̹� �ൿ���� ������ �¿� ������
            // ������ų �� �ִ� ĳ���͸� �켱 Ÿ������ �����մϴ�.
            int targetGridIndex = FindBestBlobTargetGridIndex(
                monsterUnit,
                attackSkill,
                gridManager);

            if (targetGridIndex < 0)
                return plan;

            BattleGridEffectController gridEffectController =
                Object.FindFirstObjectByType<BattleGridEffectController>(FindObjectsInactive.Include);

            // ������ �̵��� �ڸ��� ������ ����� �����̹Ƿ� �� �� �̵��� �켱 �õ��մϴ�.
            // ���� ������ ��ġ�� ���� ���̶�� ���� ������ ���� ĭ�� �켱�մϴ�.
            Vector2Int moveOffset = GetBestCardinalMove(
                monsterUnit,
                targetGridIndex,
                attackSkill,
                gridManager,
                gridEffectController);

            int plannedMoveGridIndex = GetProjectedMainGridIndex(
                monsterUnit,
                gridManager,
                moveOffset);

            bool isCharacterCollisionMove = IsCharacterCollisionMoveCandidate(
                monsterUnit,
                plannedMoveGridIndex,
                targetGridIndex,
                gridEffectController);

            bool canMoveNormally = moveOffset != Vector2Int.zero &&
                                   CanMonsterMove(monsterUnit, gridManager, moveOffset);
            bool canMove = moveOffset != Vector2Int.zero &&
                           (canMoveNormally || isCharacterCollisionMove);

            int group = 1;

            if (canMove)
            {
                plan.Add(new MonsterAIAction(
                    MoveSkillId,
                    moveOffset,
                    MonsterAISlotPreference.Front,
                    group,
                    0
                ));
            }

            int projectedGridIndex = GetProjectedMainGridIndex(
                monsterUnit,
                gridManager,
                canMove ? moveOffset : Vector2Int.zero);

            // �̵� ��ǥ�� ���� ������ ������ �켱 Ÿ������ �����մϴ�.
            // �ٸ� ĳ���Ͱ� ���� ������ �������� �̵�/���� ������ �ٲ��� �ʽ��ϴ�.
            int attackTargetGridIndex = CanAttackTargetFromGrid(
                monsterUnit,
                projectedGridIndex,
                targetGridIndex,
                attackSkill,
                gridManager)
                ? targetGridIndex
                : -1;

            // ���� ���� �ȿ� ĳ���Ͱ� ������ �� ĳ���� ������ �����մϴ�.
            // ���� �ȿ� ĳ���Ͱ� ��� ���� ������ ������� �ʰ� �̵� �� �ٶ󺸴� ������ �����մϴ�.
            BattleDirection attackDirection = attackTargetGridIndex >= 0
                ? GetBlobAttackDirection(projectedGridIndex, attackTargetGridIndex, gridManager)
                : ResolveForwardAttackDirection(
                    monsterUnit,
                    moveOffset,
                    projectedGridIndex,
                    targetGridIndex,
                    gridManager);

            plan.Add(new MonsterAIAction(
                AttackSkillId,
                Vector2Int.zero,
                MonsterAISlotPreference.SameSlot,
                group,
                canMove ? 1 : 0,
                projectedGridIndex,
                true,
                attackDirection,
                rangeOriginCasterGridIndex: projectedGridIndex
            ));

            return plan;
        }

        private int FindBestBlobTargetGridIndex(
            MonsterUnit monsterUnit,
            MonsterSkillData attackSkill,
            GridManager gridManager)
        {
            if (monsterUnit == null || gridManager == null || monsterUnit.MainGridIndex < 0)
                return -1;

            List<int> targets = FindCharacterTargetGridIndices();

            if (targets == null || targets.Count == 0)
                return -1;

            Vector2Int currentCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);
            int bestAttackableTarget = -1;
            int bestAttackableDistance = int.MaxValue;
            int nearestTarget = -1;
            int nearestDistance = int.MaxValue;

            for (int i = 0; i < targets.Count; i++)
            {
                int candidateGridIndex = targets[i];
                Vector2Int candidateCoord = gridManager.IndexToCoord(candidateGridIndex);
                int distance =
                    Mathf.Abs(candidateCoord.x - currentCoord.x) +
                    Mathf.Abs(candidateCoord.y - currentCoord.y);

                if (distance < nearestDistance ||
                    (distance == nearestDistance && candidateGridIndex < nearestTarget))
                {
                    nearestDistance = distance;
                    nearestTarget = candidateGridIndex;
                }

                if (!CanAttackTargetThisTurn(
                        monsterUnit,
                        candidateGridIndex,
                        attackSkill,
                        gridManager))
                {
                    continue;
                }

                if (distance < bestAttackableDistance ||
                    (distance == bestAttackableDistance && candidateGridIndex < bestAttackableTarget))
                {
                    bestAttackableDistance = distance;
                    bestAttackableTarget = candidateGridIndex;
                }
            }

            return bestAttackableTarget >= 0
                ? bestAttackableTarget
                : nearestTarget;
        }

        private bool CanAttackTargetThisTurn(
            MonsterUnit monsterUnit,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager)
        {
            if (monsterUnit == null ||
                attackSkill == null ||
                gridManager == null ||
                monsterUnit.MainGridIndex < 0 ||
                targetGridIndex < 0)
            {
                return false;
            }

            // �̹� �¿� ���� ������ ���� Ÿ�ٵ� �̹� �ൿ���� ���� ������ ������� ���ϴ�.
            // �� ��� ���� �̵� �ܰ迡���� �������� �ʰ� ����/�浹 ��Ģ�� �����ϴ�.
            if (CanAttackTargetFromGrid(
                    monsterUnit,
                    monsterUnit.MainGridIndex,
                    targetGridIndex,
                    attackSkill,
                    gridManager))
            {
                return true;
            }

            // �� ĭ ���� �̵� �� �ٷ� �¿� ������ ���������� ���� �������� �Ǵ��մϴ�.
            for (int i = 0; i < MoveDirections.Length; i++)
            {
                Vector2Int moveOffset = MoveDirections[i];

                if (!CanMonsterMove(monsterUnit, gridManager, moveOffset))
                    continue;

                int projectedGridIndex = GetProjectedMainGridIndex(
                    monsterUnit,
                    gridManager,
                    moveOffset);

                if (CanAttackTargetFromGrid(
                        monsterUnit,
                        projectedGridIndex,
                        targetGridIndex,
                        attackSkill,
                        gridManager))
                {
                    return true;
                }
            }

            return false;
        }

        private Vector2Int GetBestCardinalMove(
            MonsterUnit monsterUnit,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager,
            BattleGridEffectController gridEffectController)
        {
            if (monsterUnit == null ||
                gridManager == null ||
                monsterUnit.MainGridIndex < 0 ||
                targetGridIndex < 0)
            {
                return Vector2Int.zero;
            }

            Vector2Int currentCoord = gridManager.IndexToCoord(monsterUnit.MainGridIndex);
            Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);

            // Ÿ���� ��/�쿡 ������ �����ϰų� �ٸ� �������� ���ݰ��� ������ �ʽ��ϴ�.
            // Ÿ�� ������ ��� �����ϸ�, �ٷ� ���� Ÿ���� ���� ������ �浹�� �õ��մϴ�.
            if (currentCoord.y == targetCoord.y && currentCoord.x != targetCoord.x)
            {
                Vector2Int towardTarget = targetCoord.x > currentCoord.x
                    ? Vector2Int.right
                    : Vector2Int.left;

                int projectedGridIndex = GetProjectedMainGridIndex(
                    monsterUnit,
                    gridManager,
                    towardTarget);

                bool canMoveNormally = CanMonsterMove(monsterUnit, gridManager, towardTarget);
                bool canCollideWithTarget = IsCharacterCollisionMoveCandidate(
                    monsterUnit,
                    projectedGridIndex,
                    targetGridIndex,
                    gridEffectController);

                if (canMoveNormally || canCollideWithTarget)
                    return towardTarget;

                // ������ ������ ���� ��쿡�� ��ȸ �̵��� ã���ϴ�.
                // �̶��� Ÿ�ٰ��� �Ÿ��� �� �־����� ���� �̵��� ������� �ʽ��ϴ�.
                return FindBestNonRetreatMove(
                    monsterUnit,
                    targetGridIndex,
                    attackSkill,
                    gridManager,
                    gridEffectController,
                    currentCoord,
                    targetCoord,
                    excludeVerticalCollision: false);
            }

            // Ÿ���� ��/�Ʒ��� ������ �� Ÿ�ٿ��� ���� �浹�ص� �¿� ������ �������� ���մϴ�.
            // ���� ��/�� �̵����� ���� ��ġ�� �غ��ϴ� ���� �켱�ϰ� ���� �浹�� ���� �ʽ��ϴ�.
            if (currentCoord.x == targetCoord.x && currentCoord.y != targetCoord.y)
            {
                Vector2Int horizontalMove = FindBestHorizontalSetupMove(
                    monsterUnit,
                    targetGridIndex,
                    attackSkill,
                    gridManager,
                    gridEffectController);

                if (horizontalMove != Vector2Int.zero)
                    return horizontalMove;

                return FindBestNonRetreatMove(
                    monsterUnit,
                    targetGridIndex,
                    attackSkill,
                    gridManager,
                    gridEffectController,
                    currentCoord,
                    targetCoord,
                    excludeVerticalCollision: true);
            }

            // �밢���� �ִ� ��쿡�� ���� Ÿ���� �¿� ���� ��ġ�� �غ��ϴ� ���� �̵��� ���մϴ�.
            // ĳ���� ĭ���� ���� ���� �浹�� �¿� ������ �� ��쿡�� ����մϴ�.
            return FindBestNonRetreatMove(
                monsterUnit,
                targetGridIndex,
                attackSkill,
                gridManager,
                gridEffectController,
                currentCoord,
                targetCoord,
                excludeVerticalCollision: true);
        }

        private Vector2Int FindBestHorizontalSetupMove(
            MonsterUnit monsterUnit,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager,
            BattleGridEffectController gridEffectController)
        {
            Vector2Int bestOffset = Vector2Int.zero;
            int bestSetupDistance = int.MaxValue;
            bool bestIsRisky = true;
            int bestTargetDistance = int.MaxValue;
            Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);

            Vector2Int[] horizontalDirections =
            {
                Vector2Int.left,
                Vector2Int.right
            };

            for (int i = 0; i < horizontalDirections.Length; i++)
            {
                Vector2Int offset = horizontalDirections[i];

                if (!CanMonsterMove(monsterUnit, gridManager, offset))
                    continue;

                int projectedGridIndex = GetProjectedMainGridIndex(monsterUnit, gridManager, offset);
                Vector2Int projectedCoord = gridManager.IndexToCoord(projectedGridIndex);
                bool candidateCanAttack = CanAttackTargetFromGrid(
                    monsterUnit,
                    projectedGridIndex,
                    targetGridIndex,
                    attackSkill,
                    gridManager);
                int setupDistance = candidateCanAttack
                    ? 0
                    : GetAttackSetupDistance(
                        monsterUnit,
                        projectedGridIndex,
                        targetGridIndex,
                        attackSkill,
                        gridManager);
                bool isRisky = IsRiskyGridEffectDestination(projectedGridIndex, gridEffectController);
                int targetDistance =
                    Mathf.Abs(targetCoord.x - projectedCoord.x) +
                    Mathf.Abs(targetCoord.y - projectedCoord.y);

                bool isBetter = bestOffset == Vector2Int.zero ||
                                setupDistance < bestSetupDistance ||
                                (setupDistance == bestSetupDistance && bestIsRisky && !isRisky) ||
                                (setupDistance == bestSetupDistance && bestIsRisky == isRisky &&
                                 targetDistance < bestTargetDistance);

                if (!isBetter)
                    continue;

                bestOffset = offset;
                bestSetupDistance = setupDistance;
                bestIsRisky = isRisky;
                bestTargetDistance = targetDistance;
            }

            return bestOffset;
        }

        private Vector2Int FindBestNonRetreatMove(
            MonsterUnit monsterUnit,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager,
            BattleGridEffectController gridEffectController,
            Vector2Int currentCoord,
            Vector2Int targetCoord,
            bool excludeVerticalCollision)
        {
            int currentTargetDistance =
                Mathf.Abs(targetCoord.x - currentCoord.x) +
                Mathf.Abs(targetCoord.y - currentCoord.y);

            Vector2Int bestOffset = Vector2Int.zero;
            bool bestCanAttack = false;
            int bestSetupDistance = int.MaxValue;
            bool bestIsRisky = true;
            int bestTargetDistance = int.MaxValue;

            for (int i = 0; i < MoveDirections.Length; i++)
            {
                Vector2Int offset = MoveDirections[i];
                int projectedGridIndex = GetProjectedMainGridIndex(monsterUnit, gridManager, offset);
                bool canMoveNormally = CanMonsterMove(monsterUnit, gridManager, offset);
                bool isCollision = IsCharacterCollisionMoveCandidate(
                    monsterUnit,
                    projectedGridIndex,
                    targetGridIndex,
                    gridEffectController);

                if (!canMoveNormally && !isCollision)
                    continue;

                if (isCollision && excludeVerticalCollision && offset.y != 0)
                    continue;

                Vector2Int projectedCoord = currentCoord + offset;
                int targetDistance =
                    Mathf.Abs(targetCoord.x - projectedCoord.x) +
                    Mathf.Abs(targetCoord.y - projectedCoord.y);

                // ���� ������ ���� �����̴��� ���� Ÿ�ٿ��Լ� �־����� ����� ���� �ʽ��ϴ�.
                if (targetDistance > currentTargetDistance)
                    continue;

                // �浹�� �¿� ���� ��ġ�� ����� ���� �̵����� �켱���� �ʽ��ϴ�.
                bool candidateCanAttack = !isCollision && CanAttackTargetFromGrid(
                    monsterUnit,
                    projectedGridIndex,
                    targetGridIndex,
                    attackSkill,
                    gridManager);
                int setupDistance = candidateCanAttack
                    ? 0
                    : GetAttackSetupDistance(
                        monsterUnit,
                        projectedGridIndex,
                        targetGridIndex,
                        attackSkill,
                        gridManager);
                bool isRisky = IsRiskyGridEffectDestination(projectedGridIndex, gridEffectController);

                bool isBetter = bestOffset == Vector2Int.zero;

                if (!isBetter && candidateCanAttack != bestCanAttack)
                    isBetter = candidateCanAttack;
                else if (!isBetter && setupDistance != bestSetupDistance)
                    isBetter = setupDistance < bestSetupDistance;
                else if (!isBetter && isRisky != bestIsRisky)
                    isBetter = !isRisky;
                else if (!isBetter && targetDistance != bestTargetDistance)
                    isBetter = targetDistance < bestTargetDistance;

                if (!isBetter)
                    continue;

                bestOffset = offset;
                bestCanAttack = candidateCanAttack;
                bestSetupDistance = setupDistance;
                bestIsRisky = isRisky;
                bestTargetDistance = targetDistance;
            }

            return bestOffset;
        }

        private int GetAttackSetupDistance(
            MonsterUnit monsterUnit,
            int originGridIndex,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager)
        {
            if (monsterUnit == null ||
                attackSkill == null ||
                gridManager == null ||
                originGridIndex < 0 ||
                targetGridIndex < 0)
            {
                return int.MaxValue;
            }

            Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
            int bestDistance = int.MaxValue;
            int cellCount = gridManager.Width * gridManager.Height;

            for (int gridIndex = 0; gridIndex < cellCount; gridIndex++)
            {
                if (gridManager.GetCellByIndex(gridIndex) == null)
                    continue;

                if (!CanAttackTargetFromGrid(
                        monsterUnit,
                        gridIndex,
                        targetGridIndex,
                        attackSkill,
                        gridManager))
                {
                    continue;
                }

                Vector2Int attackOriginCoord = gridManager.IndexToCoord(gridIndex);
                int distance =
                    Mathf.Abs(attackOriginCoord.x - originCoord.x) +
                    Mathf.Abs(attackOriginCoord.y - originCoord.y);

                if (distance < bestDistance)
                    bestDistance = distance;
            }

            return bestDistance;
        }

        private static bool IsCharacterCollisionMoveCandidate(
            MonsterUnit monsterUnit,
            int projectedGridIndex,
            int targetGridIndex,
            BattleGridEffectController gridEffectController)
        {
            if (monsterUnit == null || projectedGridIndex < 0 || targetGridIndex < 0)
                return false;

            if (projectedGridIndex != targetGridIndex)
                return false;

            if (gridEffectController != null && gridEffectController.IsBlocked(projectedGridIndex))
                return false;

            if (BattleOccupancyService.IsOccupiedByMonster(projectedGridIndex, monsterUnit))
                return false;

            if (!BattleOccupancyService.TryGetCharacterAtGrid(
                    projectedGridIndex,
                    out BattleCharacter character) ||
                character == null ||
                character.RuntimeData == null ||
                character.RuntimeData.IsDead)
            {
                return false;
            }

            return true;
        }

        private static bool IsRiskyGridEffectDestination(
            int gridIndex,
            BattleGridEffectController gridEffectController)
        {
            if (gridIndex < 0 || gridEffectController == null)
                return false;

            if (!gridEffectController.State.TryGetEffectId(gridIndex, out string gridEffectId) ||
                string.IsNullOrWhiteSpace(gridEffectId))
            {
                return false;
            }

            // ������ ���Ϳ��� ������� �����Ƿ� ���ӿ��� ���� ������ �ƴմϴ�.
            return !string.Equals(
                gridEffectId,
                ResidueGridEffectId,
                System.StringComparison.OrdinalIgnoreCase);
        }

        private int FindNearestAttackableCharacterTarget(
            MonsterUnit monsterUnit,
            int originGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager)
        {
            if (monsterUnit == null ||
                originGridIndex < 0 ||
                attackSkill == null ||
                gridManager == null)
            {
                return -1;
            }

            List<int> targets = FindCharacterTargetGridIndices();
            Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
            int nearestGridIndex = -1;
            int nearestDistance = int.MaxValue;

            for (int i = 0; i < targets.Count; i++)
            {
                int targetGridIndex = targets[i];

                if (!CanAttackTargetFromGrid(
                    monsterUnit,
                    originGridIndex,
                    targetGridIndex,
                    attackSkill,
                    gridManager))
                {
                    continue;
                }

                Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);
                int distance =
                    Mathf.Abs(targetCoord.x - originCoord.x) +
                    Mathf.Abs(targetCoord.y - originCoord.y);

                if (distance >= nearestDistance)
                    continue;

                nearestDistance = distance;
                nearestGridIndex = targetGridIndex;
            }

            return nearestGridIndex;
        }

        private bool CanAttackTargetFromGrid(
            MonsterUnit monsterUnit,
            int originGridIndex,
            int targetGridIndex,
            MonsterSkillData attackSkill,
            GridManager gridManager)
        {
            if (monsterUnit == null ||
                attackSkill == null ||
                gridManager == null ||
                originGridIndex < 0 ||
                targetGridIndex < 0)
            {
                return false;
            }

            RangeDatabase rangeDatabase = DataManager.Instance?.RangeDatabase;

            if (rangeDatabase == null)
                return false;

            Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
            Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);

            // ������ ������ �¿� ���� �����̹Ƿ� ���� ���� ���ο� �ִ� ��� ��ȿ�մϴ�.
            if (originCoord.y != targetCoord.y)
                return false;

            BattleDirection direction = targetCoord.x >= originCoord.x
                ? BattleDirection.Right
                : BattleDirection.Left;

            List<int> attackRange = MonsterSkillRangeService.BuildRangeGridIndices(
                monsterUnit,
                attackSkill,
                gridManager,
                direction == BattleDirection.Right,
                originGridIndex,
                rangeDatabase);

            return attackRange != null && attackRange.Contains(targetGridIndex);
        }

        private static BattleDirection GetBlobAttackDirection(
            int originGridIndex,
            int targetGridIndex,
            GridManager gridManager)
        {
            if (gridManager == null || originGridIndex < 0 || targetGridIndex < 0)
                return BattleDirection.Right;

            Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
            Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);

            return targetCoord.x >= originCoord.x
                ? BattleDirection.Right
                : BattleDirection.Left;
        }

        private static BattleDirection ResolveForwardAttackDirection(
            MonsterUnit monsterUnit,
            Vector2Int moveOffset,
            int originGridIndex,
            int targetGridIndex,
            GridManager gridManager)
        {
            // ���� �̵��� �����ߴٸ� �̵� ���� �� �ٶ󺸰� �Ǵ� ������ �� �����Դϴ�.
            if (moveOffset.x > 0)
                return BattleDirection.Right;

            if (moveOffset.x < 0)
                return BattleDirection.Left;

            // ���� �̵��̰ų� �̵����� ���� ���, ���� ������ ������ Ÿ���� �¿� ��� �ʿ� �ִ����� ������ ����ϴ�.
            if (gridManager != null && originGridIndex >= 0 && targetGridIndex >= 0)
            {
                Vector2Int originCoord = gridManager.IndexToCoord(originGridIndex);
                Vector2Int targetCoord = gridManager.IndexToCoord(targetGridIndex);

                if (targetCoord.x > originCoord.x)
                    return BattleDirection.Right;

                if (targetCoord.x < originCoord.x)
                    return BattleDirection.Left;
            }

            BattleUnitFacing facing = monsterUnit != null
                ? monsterUnit.GetComponent<BattleUnitFacing>()
                : null;

            return facing == null || facing.IsFacingRight
                ? BattleDirection.Right
                : BattleDirection.Left;
        }
    }
}
