using System;
using System.Collections.Generic;
using Relic.Gameplay.Data;

public static class LobbyRelicShopPurchaseLimit
{
    public static bool HasPurchasedOffer(LobbyRuntimeData runtime)
    {
        if (runtime == null)
            return false;

        if (runtime.RelicShopPurchaseLocked)
            return true;

        // ���� ���� ������ ȣȯ:
        // �� ��� �ʵ尡 ����� ���� ������ ���̺�� ���� ���� ������ OwnedRelicIds�� ���� ������
        // �̹� ������ ���·� �����ϰ� �� ��ݰ����� �°��մϴ�.
        if (HasLegacyPurchasedOffer(runtime))
        {
            runtime.RelicShopPurchaseLocked = true;
            return true;
        }

        return false;
    }

    public static void LockAfterPurchase(LobbyRuntimeData runtime)
    {
        if (runtime == null)
            return;

        runtime.RelicShopPurchaseLocked = true;
    }

    public static void ResetAfterExploration(LobbyRuntimeData runtime)
    {
        if (runtime == null)
            return;

        runtime.RelicShopPurchaseLocked = false;
        runtime.RelicRefreshCount = 0;
        runtime.RelicOfferSeed = 0;
        runtime.RelicOfferIds?.Clear();
    }

    private static bool HasLegacyPurchasedOffer(LobbyRuntimeData runtime)
    {
        if (runtime?.RelicOfferIds == null || runtime.OwnedRelicIds == null)
            return false;

        for (int i = 0; i < runtime.RelicOfferIds.Count; i++)
        {
            if (Contains(runtime.OwnedRelicIds, runtime.RelicOfferIds[i]))
                return true;
        }

        return false;
    }

    private static bool Contains(IEnumerable<string> ids, string target)
    {
        if (ids == null || string.IsNullOrWhiteSpace(target))
            return false;

        string normalizedTarget = target.Trim();
        foreach (string id in ids)
        {
            if (string.Equals(id?.Trim(), normalizedTarget, StringComparison.Ordinal))
                return true;
        }

        return false;
    }
}
