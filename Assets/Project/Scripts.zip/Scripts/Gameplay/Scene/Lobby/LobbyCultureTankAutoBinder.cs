using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class LobbyCultureTankAutoBinder
{
    private const string LobbySceneName = "Lobby";
    private const string CultureTankNamePrefix = "CultureTank";
    private const string ResearcherObjectName = "Researcher";

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Register()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
        SceneManager.sceneLoaded += OnSceneLoaded;
        Bind(SceneManager.GetActiveScene());
    }

    private static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Bind(scene);
    }

    private static void Bind(Scene scene)
    {
        if (!scene.IsValid() ||
            !string.Equals(scene.name, LobbySceneName, StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        GameObject[] roots = scene.GetRootGameObjects();
        BindCultureTanks(roots);
        BindResearchers(roots);
    }

    private static void BindCultureTanks(GameObject[] roots)
    {
        for (int rootIndex = 0; rootIndex < roots.Length; rootIndex++)
        {
            Transform[] transforms = roots[rootIndex].GetComponentsInChildren<Transform>(true);

            for (int transformIndex = 0; transformIndex < transforms.Length; transformIndex++)
            {
                Transform candidate = transforms[transformIndex];
                if (candidate == null ||
                    !candidate.name.StartsWith(CultureTankNamePrefix, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (candidate.GetComponent<SpriteRenderer>() == null)
                    continue;

                if (candidate.GetComponent<LobbyCultureTankController>() == null)
                    candidate.gameObject.AddComponent<LobbyCultureTankController>();
            }
        }
    }

    /// <summary>
    /// �� ���� ��� Researcher�� Ȯ���մϴ�.
    /// LobbyPanelTransitionButton�� �ִ� ���� Researcher�� ��ȯ ��ư�� ����ϰ�,
    /// ��ȯ ��ư�� ���� ���� Researcher���� ���� ��ȣ�ۿ� ��ũ��Ʈ�� �����մϴ�.
    /// </summary>
    private static void BindResearchers(GameObject[] roots)
    {
        if (roots == null)
            return;

        for (int rootIndex = 0; rootIndex < roots.Length; rootIndex++)
        {
            GameObject rootObject = roots[rootIndex];
            if (rootObject == null)
                continue;

            Transform[] transforms = rootObject.GetComponentsInChildren<Transform>(true);

            for (int transformIndex = 0; transformIndex < transforms.Length; transformIndex++)
            {
                Transform researcher = transforms[transformIndex];
                if (researcher == null ||
                    !string.Equals(researcher.name, ResearcherObjectName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                BindSingleResearcher(researcher);
            }
        }
    }

    private static void BindSingleResearcher(Transform researcher)
    {
        Transform clickTarget = ResolveClickableTarget(researcher);
        if (clickTarget == null)
            return;

        LobbyResearcherCultureTankInteraction legacyInteraction =
            clickTarget.GetComponent<LobbyResearcherCultureTankInteraction>();

        bool usesPanelTransition = HasLobbyPanelTransitionButton(researcher, clickTarget);

        if (usesPanelTransition)
        {
            // �гΰ� ��� ������ LobbyPanelTransitionButton�� ȭ���� ���� �߰� ������ ó���մϴ�.
            // ���� ��ȣ�ۿ��� ���ÿ� presenter.Open()�� ȣ������ �ʵ��� ��Ȱ��ȭ�մϴ�.
            if (legacyInteraction != null)
                legacyInteraction.enabled = false;

            return;
        }

        // ��ȯ ��ư�� ������� �ʴ� ���� Researcher�� ���� ��ȣ�ۿ��� �����մϴ�.
        if (legacyInteraction == null)
            legacyInteraction = clickTarget.gameObject.AddComponent<LobbyResearcherCultureTankInteraction>();

        legacyInteraction.enabled = true;
    }

    private static bool HasLobbyPanelTransitionButton(Transform researcher, Transform clickTarget)
    {
        if (clickTarget != null && clickTarget.GetComponent<LobbyPanelTransitionButton>() != null)
            return true;

        if (researcher == null)
            return false;

        if (researcher.GetComponent<LobbyPanelTransitionButton>() != null)
            return true;

        if (researcher.GetComponentInChildren<LobbyPanelTransitionButton>(true) != null)
            return true;

        return researcher.GetComponentInParent<LobbyPanelTransitionButton>(true) != null;
    }

    private static Transform ResolveClickableTarget(Transform root)
    {
        if (root == null)
            return null;

        if (root.GetComponent<SpriteRenderer>() != null || root.GetComponent<Collider2D>() != null)
            return root;

        SpriteRenderer childRenderer = root.GetComponentInChildren<SpriteRenderer>(true);
        return childRenderer != null ? childRenderer.transform : root;
    }
}
