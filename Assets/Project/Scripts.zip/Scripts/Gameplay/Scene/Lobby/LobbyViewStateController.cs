using UnityEngine;

public enum LobbyViewState
{
    Lobby,
    CharacterSelection,
    Position
}

public sealed class LobbyViewStateController : MonoBehaviour
{
    [Header("Lobby Objects")]
    [SerializeField] private GameObject backMain;
    [SerializeField] private GameObject effectLobby;
    [SerializeField] private GameObject effectCharacter;
    [SerializeField] private GameObject lobbyMainPanel;
    [SerializeField] private GameObject characterSettingPanel;
    [SerializeField] private GameObject characterPreviewSpawnRoot;

    [Header("Position Objects")]
    [SerializeField] private GameObject position;
    [SerializeField] private GameObject positionPanel;
    [SerializeField] private GameObject settingButton;

    [Header("Lighting")]
    [SerializeField] private GameObject lobbyDirectionalLight;
    [SerializeField] private GameObject positionDirectionalLight;

    public LobbyViewState CurrentState { get; private set; }

    private void Start()
    {
        ShowPosition();
    }

    public void ShowLobby()
    {
        ApplyState(LobbyViewState.Lobby);
    }

    public void ShowCharacterSelection()
    {
        ApplyState(LobbyViewState.CharacterSelection);
    }

    public void ShowPosition()
    {
        ApplyState(LobbyViewState.Position);
    }

    public void TogglePosition()
    {
        ApplyState(CurrentState == LobbyViewState.Position
            ? LobbyViewState.Lobby
            : LobbyViewState.Position);
    }

    private void ApplyState(LobbyViewState state)
    {
        CurrentState = state;

        bool isLobby = state == LobbyViewState.Lobby;
        bool isCharacterSelection = state == LobbyViewState.CharacterSelection;
        bool isPosition = state == LobbyViewState.Position;

        SetActive(backMain, !isPosition);
        SetActive(effectLobby, isLobby);
        SetActive(effectCharacter, isCharacterSelection);
        SetActive(lobbyMainPanel, isLobby);
        SetActive(characterSettingPanel, isCharacterSelection);
        SetActive(characterPreviewSpawnRoot, isCharacterSelection);
        SetActive(position, isPosition);
        // CharacterSettingPanel�� SettingButton�� PositionPanel�� �ڽ��̹Ƿ�
        // ĳ���� ���� ȭ�鿡���� PositionPanel ��Ʈ�� �����մϴ�.
        SetActive(positionPanel, isPosition || isCharacterSelection);

        // ĳ���� ���� ȭ�鿡���� SettingButton�� ��� ǥ���մϴ�.
        if (settingButton == null)
            settingButton = FindSceneObject("SettingButton");

        SetActive(settingButton, isPosition || isCharacterSelection);
        SetActive(lobbyDirectionalLight, !isPosition);
        SetActive(positionDirectionalLight, isPosition);
    }



    private void LateUpdate()
    {
        // �ٸ� ��ȯ ��ũ��Ʈ�� �ν����� �迭���� PositionPanel/SettingButton��
        // ��Ȱ��ȭ�ϴ��� ĳ���� ���� ȭ�鿡���� ������ �ܰ迡�� �ٽ� �����մϴ�.
        if (CurrentState != LobbyViewState.CharacterSelection)
            return;

        if (positionPanel == null)
            positionPanel = FindSceneObject("PositionPanel");

        if (settingButton == null)
            settingButton = FindSceneObject("SettingButton");

        SetActive(positionPanel, true);
        SetActive(settingButton, true);
    }

    private static GameObject FindSceneObject(string objectName)
    {
        if (string.IsNullOrWhiteSpace(objectName))
            return null;

        GameObject[] objects = FindObjectsByType<GameObject>(
            FindObjectsInactive.Include,
            FindObjectsSortMode.None);

        for (int i = 0; i < objects.Length; i++)
        {
            GameObject candidate = objects[i];

            if (candidate != null && candidate.name == objectName)
                return candidate;
        }

        return null;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
            target.SetActive(active);
    }
}
