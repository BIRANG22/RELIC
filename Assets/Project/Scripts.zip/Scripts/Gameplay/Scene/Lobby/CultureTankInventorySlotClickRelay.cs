using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class CultureTankInventorySlotClickRelay : MonoBehaviour, IPointerClickHandler
{
    private Button button;
    private string itemId;
    private bool selectionEnabled;
    private Action<string> onSelected;

    private void Awake()
    {
        if (button == null) button = GetComponent<Button>();
        BindButton();
    }

    public void Configure(Button targetButton, string configuredItemId, bool enabled, Action<string> callback)
    {
        button = targetButton != null ? targetButton : GetComponent<Button>();
        itemId = string.IsNullOrWhiteSpace(configuredItemId) ? string.Empty : configuredItemId.Trim();
        selectionEnabled = enabled && !string.IsNullOrWhiteSpace(itemId);
        onSelected = callback;
        BindButton();
        if (button != null) button.interactable = selectionEnabled;
    }

    private void BindButton()
    {
        if (button == null) return;
        button.onClick.RemoveListener(HandleClick);
        button.onClick.AddListener(HandleClick);
    }

    private void HandleClick()
    {
        InvokeSelection();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // ���� ��Ʈ�� Button�� ���� StorageSlotUI �����յ� Ŭ���� �� �ְ� �մϴ�.
        // Button�� �ִ� ��쿡�� Button.onClick���� ó���ϹǷ� �ߺ� �������� �ʽ��ϴ�.
        if (button != null)
            return;

        InvokeSelection();
    }

    private void InvokeSelection()
    {
        if (!selectionEnabled || string.IsNullOrWhiteSpace(itemId))
            return;

        onSelected?.Invoke(itemId);
    }
}
