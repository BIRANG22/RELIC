using UnityEngine;
using UnityEngine.UI;

public readonly struct MapLineLayout
{
    public Vector2 AnchoredPosition { get; }
    public Vector2 Size { get; }
    public float RotationDegrees { get; }

    public MapLineLayout(Vector2 anchoredPosition, Vector2 size, float rotationDegrees)
    {
        AnchoredPosition = anchoredPosition;
        Size = size;
        RotationDegrees = rotationDegrees;
    }
}

public class MapLineView : MonoBehaviour
{
    [Header("Line Visual")]
    [SerializeField] private Image lineImage;
    [SerializeField] private Sprite lineSprite;
    [SerializeField, Min(0f)] private float thickness = 13f;

    [Header("Dotted Line Clip")]
    [Tooltip("�� ���� �̹����� �߶� ������ Mask �����Դϴ�. ��� ������ �ڽĿ��� �ڵ����� ã���ϴ�.")]
    [SerializeField] private RectTransform clipArea;

    [Tooltip("���̿� �������� ������ �� ���� �̹����Դϴ�. ��� ������ Line Image�� RectTransform�� ����մϴ�.")]
    [SerializeField] private RectTransform dottedImageRect;

    private Vector2 originalDottedSize;
    private Vector3 originalDottedScale;
    private bool dottedVisualCached;

    private bool currentAvailable;
    private bool currentTraversed;

    private void Awake()
    {
        ResolveReferences();
        PrepareRotationSafeMask();
        CacheDottedVisual();
    }

    public void Setup(Vector2 from, Vector2 to)
    {
        RectTransform rect = GetComponent<RectTransform>();
        if (rect == null)
            return;

        ResolveReferences();
        PrepareRotationSafeMask();
        CacheDottedVisual();

        // ��� �߽ɿ��� ���� ��� �߽ɱ��� ��Ȯ�� �����մϴ�.
        MapLineLayout layout = CalculateLayout(from, to, thickness, 0f);

        rect.anchorMin = new Vector2(0f, 0.5f);
        rect.anchorMax = new Vector2(0f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = layout.AnchoredPosition;
        rect.sizeDelta = layout.Size;
        rect.localScale = Vector3.one;
        rect.localRotation = Quaternion.Euler(0f, 0f, layout.RotationDegrees);

        if (clipArea != null)
        {
            // ����ũ�� ������ ���� X���� �������� ���� �����մϴ�.
            // �θ� ���� ������Ʈ�� �Բ� ȸ���ϹǷ� ��/�Ʒ� �밢�� ��� ���� ������� �߸��ϴ�.
            clipArea.anchorMin = new Vector2(0.5f, 0.5f);
            clipArea.anchorMax = new Vector2(0.5f, 0.5f);
            clipArea.pivot = new Vector2(0.5f, 0.5f);
            clipArea.anchoredPosition = Vector2.zero;
            clipArea.sizeDelta = new Vector2(layout.Size.x, layout.Size.y);
            clipArea.localScale = Vector3.one;
            clipArea.localRotation = Quaternion.identity;
        }

        if (dottedImageRect != null && dottedVisualCached)
        {
            // �� ���� ������ ����/������ ������ �ʵ��� ���� ũ��� �������� �����մϴ�.
            dottedImageRect.anchorMin = new Vector2(0f, 0.5f);
            dottedImageRect.anchorMax = new Vector2(0f, 0.5f);
            dottedImageRect.pivot = new Vector2(0f, 0.5f);
            dottedImageRect.anchoredPosition = Vector2.zero;
            dottedImageRect.sizeDelta = originalDottedSize;
            dottedImageRect.localScale = originalDottedScale;
            dottedImageRect.localRotation = Quaternion.identity;
        }

        if (lineImage == null)
            return;

        if (lineSprite != null)
            lineImage.sprite = lineSprite;

        lineImage.preserveAspect = false;
        lineImage.raycastTarget = false;
        ApplyLineColor();
    }

    public void SetAvailabilityVisual(bool available)
    {
        SetProgressVisual(available, false);
    }

    public void SetProgressVisual(bool available, bool traversed)
    {
        currentAvailable = available;
        currentTraversed = traversed;
        ApplyLineColor();
    }

    private void ApplyLineColor()
    {
        if (lineImage == null)
            return;

        Color availableColor = new Color32(0xFF, 0xFF, 0xFF, 0xFF);
        Color unavailableColor = new Color32(0x77, 0x77, 0x77, 0xFF);
        lineImage.color = (currentAvailable || currentTraversed) ? availableColor : unavailableColor;
    }

    private void ResolveReferences()
    {
        if (clipArea == null)
        {
            // ȸ���� ������ �Ϲ� Mask�� �켱 ã���ϴ�.
            Mask mask = GetComponentInChildren<Mask>(true);
            if (mask != null)
            {
                clipArea = mask.GetComponent<RectTransform>();
            }
            else
            {
                RectMask2D rectMask = GetComponentInChildren<RectMask2D>(true);
                if (rectMask != null)
                    clipArea = rectMask.GetComponent<RectTransform>();
            }
        }

        if (lineImage == null)
        {
            Image[] images = GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
            {
                RectTransform imageRect = images[i].rectTransform;
                if (clipArea == null || imageRect == clipArea || !imageRect.IsChildOf(clipArea))
                    continue;

                lineImage = images[i];
                break;
            }

            if (lineImage == null && images.Length > 0)
                lineImage = images[0];
        }

        if (dottedImageRect == null && lineImage != null)
            dottedImageRect = lineImage.rectTransform;
    }

    private void PrepareRotationSafeMask()
    {
        if (clipArea == null)
            return;

        // RectMask2D�� ȸ���� UI���� �� ���� Ŭ���� ������ �밢�� ���⿡ ����
        // ������ ����� �� �ֽ��ϴ�. ���ٽ� ��� Mask�� �ٲ� ȸ���� �簢�� �״�� �ڸ��ϴ�.
        RectMask2D rectMask = clipArea.GetComponent<RectMask2D>();
        if (rectMask != null)
            rectMask.enabled = false;

        Mask mask = clipArea.GetComponent<Mask>();
        if (mask == null)
            mask = clipArea.gameObject.AddComponent<Mask>();

        Image maskGraphic = clipArea.GetComponent<Image>();
        if (maskGraphic == null)
            maskGraphic = clipArea.gameObject.AddComponent<Image>();

        maskGraphic.raycastTarget = false;
        maskGraphic.color = Color.white;
        mask.showMaskGraphic = false;
    }

    private void CacheDottedVisual()
    {
        if (dottedVisualCached || dottedImageRect == null)
            return;

        originalDottedSize = dottedImageRect.sizeDelta;
        originalDottedScale = dottedImageRect.localScale;
        dottedVisualCached = true;
    }

    public static MapLineLayout CalculateLayout(
        Vector2 from,
        Vector2 to,
        float thickness,
        float endpointInset)
    {
        Vector2 direction = to - from;
        float trimmedDistance = Mathf.Max(0f, direction.magnitude - Mathf.Max(0f, endpointInset) * 2f);
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        return new MapLineLayout(
            (from + to) * 0.5f,
            new Vector2(trimmedDistance, Mathf.Max(0f, thickness)),
            angle);
    }
}
