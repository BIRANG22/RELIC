using Relic.Gameplay.Data;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ���� ���õ� ��Ƽ ĳ���͵��� ������ �κ��丮 �гο� ǥ���մϴ�.
/// PortraitImage���� CharacterIconDatabase�� Mark �̹����� ǥ���ϰ�,
/// PortraitImage2���� CharacterIconDatabase�� Mark2 �̹����� ǥ���մϴ�.
/// </summary>
public class PartyCharacterSlotListUI : MonoBehaviour
{
    [Header("Slots")]
    [SerializeField] private PartyCharacterSlotUI[] slots;

    private const string BackImageName = "Backimage";
    private const string MaskName = "mask";
    private const string PortraitImageName = "PortraitImage";
    private const string PortraitImage2Name = "PortraitImage2";
    private const string NameTextName = "Name";

    private void OnEnable()
    {
        Refresh();
    }

    public void Refresh()
    {
        if (DataManager.Instance == null)
        {
            ClearAll();
            return;
        }

        PartyRuntimeStore partyStore = DataManager.Instance.PartyRuntimeStore;

        if (partyStore == null)
        {
            ClearAll();
            return;
        }

        ClearAll();

        for (int partyIndex = 0; partyIndex < slots.Length; partyIndex++)
        {
            PartyCharacterSlotUI slot = slots[partyIndex];

            if (slot == null)
                continue;

            string characterId = partyStore.GetCharacterId(partyIndex);

            // �� ��Ƽ ������ �״�� ��� �Ӵϴ�.
            // ���� ĳ���͸� �� �������� ����� �ʾ� ���� ��Ƽ ��ȣ�� �����մϴ�.
            if (string.IsNullOrWhiteSpace(characterId))
                continue;

            CharacterMasterData masterData = null;

            if (DataManager.Instance.CharacterDatabase != null)
                masterData = DataManager.Instance.CharacterDatabase.Get(characterId);

            Sprite markSprite = null;
            Sprite mark2Sprite = null;

            if (DataManager.Instance.CharacterIconDatabase != null)
            {
                DataManager.Instance.CharacterIconDatabase.TryGetMark(characterId, out markSprite);
                DataManager.Instance.CharacterIconDatabase.TryGetMark2(characterId, out mark2Sprite);
            }

            string characterName = masterData != null
                ? masterData.Name
                : characterId;

            ApplySlot(slot.transform, characterName, markSprite, mark2Sprite);
        }
    }

    /// <summary>
    /// ���Կ� ĳ���� �̸�, Mark, Mark2 �̹����� �����մϴ�.
    /// </summary>
    private void ApplySlot(Transform slotTransform, string characterName, Sprite markSprite, Sprite mark2Sprite)
    {
        if (slotTransform == null)
            return;

        TMP_Text nameText = FindNameText(slotTransform);

        if (nameText != null)
            nameText.text = characterName;

        Image portraitImage = FindNamedImage(slotTransform, PortraitImageName);

        if (portraitImage == null)
            Debug.LogWarning($"{gameObject.name}: {slotTransform.name} �ȿ��� {PortraitImageName} ������Ʈ�� ã�� ���߽��ϴ�.");
        else
            ApplyImage(portraitImage, markSprite);

        Image portraitImage2 = FindNamedImage(slotTransform, PortraitImage2Name);

        if (portraitImage2 != null)
            ApplyImage(portraitImage2, mark2Sprite);
    }

    /// <summary>
    /// ���� ���� �̸� �ؽ�Ʈ�� ã���ϴ�.
    /// </summary>
    private TMP_Text FindNameText(Transform slotTransform)
    {
        if (slotTransform == null)
            return null;

        Transform nameTransform = slotTransform.Find(NameTextName);

        if (nameTransform != null)
            return nameTransform.GetComponent<TMP_Text>();

        return slotTransform.GetComponentInChildren<TMP_Text>(true);
    }

    /// <summary>
    /// ���� ������ Slot_01/PortraitImage�� �켱���� ã���ϴ�.
    /// ���� ������ Backimage/mask/PortraitImage�� ȣȯ�ǵ��� ���� ã���ϴ�.
    /// </summary>
    private Image FindPortraitImage(Transform slotTransform)
    {
        return FindNamedImage(slotTransform, PortraitImageName);
    }

    private Image FindNamedImage(Transform slotTransform, string imageObjectName)
    {
        if (slotTransform == null || string.IsNullOrWhiteSpace(imageObjectName))
            return null;

        Transform directImageTransform = slotTransform.Find(imageObjectName);

        if (directImageTransform != null)
        {
            Image directImage = directImageTransform.GetComponent<Image>();

            if (directImage != null)
                return directImage;
        }

        Image[] childImages = slotTransform.GetComponentsInChildren<Image>(true);

        for (int i = 0; i < childImages.Length; i++)
        {
            Image childImage = childImages[i];

            if (childImage == null)
                continue;

            if (childImage.gameObject.name == imageObjectName)
                return childImage;
        }

        Transform backImageTransform = slotTransform.Find(BackImageName);

        if (backImageTransform != null)
        {
            Transform maskTransform = backImageTransform.Find(MaskName);

            if (maskTransform != null)
            {
                Transform oldImageTransform = maskTransform.Find(imageObjectName);

                if (oldImageTransform != null)
                {
                    Image oldImage = oldImageTransform.GetComponent<Image>();

                    if (oldImage != null)
                        return oldImage;
                }
            }
        }

        return null;
    }

    private void ApplyImage(Image image, Sprite sprite)
    {
        if (image == null)
            return;

        image.sprite = sprite;
        image.enabled = sprite != null;
        image.preserveAspect = true;
        image.raycastTarget = false;
    }

    /// <summary>
    /// ��� ������ ĳ���� �̸��� �̹����� ���ϴ�.
    /// </summary>
    private void ClearAll()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] == null)
                continue;

            ClearSlot(slots[i].transform);
        }
    }

    /// <summary>
    /// Ư�� ������ �̸��� �̹����� ���ϴ�.
    /// </summary>
    private void ClearSlot(Transform slotTransform)
    {
        if (slotTransform == null)
            return;

        TMP_Text nameText = FindNameText(slotTransform);

        if (nameText != null)
            nameText.text = string.Empty;

        Image portraitImage = FindNamedImage(slotTransform, PortraitImageName);
        Image portraitImage2 = FindNamedImage(slotTransform, PortraitImage2Name);

        ApplyImage(portraitImage, null);
        ApplyImage(portraitImage2, null);
    }
}
