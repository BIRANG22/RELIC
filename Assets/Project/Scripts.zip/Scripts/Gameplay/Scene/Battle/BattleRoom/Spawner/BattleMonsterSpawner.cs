using Relic.Gameplay.Data;
using Relic.Gameplay.Monster;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class BattleMonsterSpawner : MonoBehaviour
{
    private readonly Dictionary<string, int> displayNameSuffixCounters = new();

    [Header("Grid Root")]
    [SerializeField] private Transform gridRoot;

    [Header("Spawn Root")]
    [SerializeField] private Transform monsterRoot;

    [Header("Spawn Setting")]
    [SerializeField] private string gridNamePrefix = "Grid_";
    [SerializeField] private string spawnPointName = "Point";
    [SerializeField] private float unitSpawnZOffset = 0.01f;

    public SpawnedMonsterResult Spawn(BattleMapData spawnData)
    {
        if (spawnData == null)
            return null;

        var dm = DataManager.Instance;

        MonsterMasterData monsterData = dm.MonsterDatabase.Get(spawnData.MonsterId);

        if (monsterData == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] MonsterData ����: {spawnData.MonsterId}");
            return null;
        }

        if (monsterData.BattlePrefab == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] BattlePrefab ����: {spawnData.MonsterId}");
            return null;
        }

        var cells = spawnData.GetOccupiedCells();

        if (cells == null || cells.Count <= 0)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] ����ĭ ����: {spawnData.MonsterId}");
            return null;
        }

        int mainCell = cells[0];

        Transform spawnGrid = FindGridByIndex(mainCell);

        if (spawnGrid == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] Grid ������Ʈ ����: Grid_{mainCell:00}");
            return null;
        }

        Transform spawnPoint = FindSpawnPoint(spawnGrid);

        Vector3 spawnPosition = spawnPoint != null
            ? spawnPoint.position
            : spawnGrid.position;

        spawnPosition.z += unitSpawnZOffset;

        GameObject monster = Instantiate(
            monsterData.BattlePrefab,
            spawnPosition,
            Quaternion.identity,
            monsterRoot
        );

        SetMonsterInitialFacingLeft(monster);

        string runtimeId = MonsterRuntimeIdGenerator.Create();

        MonsterRuntimeData runtimeData =
            new MonsterRuntimeData(runtimeId, monsterData);
        ApplyDisplayNameSuffix(runtimeData);

        MonsterUnit monsterUnit = monster.GetComponent<MonsterUnit>();

        if (monsterUnit == null)
        {
            Debug.LogError($"[BattleMonsterSpawner] MonsterUnit ����: {monster.name}");
            Destroy(monster);
            return null;
        }

        monsterUnit.Initialize(runtimeData);
        monsterUnit.SetOccupiedCells(cells);

        return new SpawnedMonsterResult
        {
            RuntimeData = runtimeData,
            MonsterTransform = monster.transform
        };
    }

    private Transform FindGridByIndex(int gridIndex)
    {
        if (gridRoot == null)
        {
            Debug.LogError("[BattleMonsterSpawner] gridRoot�� ������� �ʾҽ��ϴ�.");
            return null;
        }

        string gridName = $"{gridNamePrefix}{gridIndex:00}";

        Transform child = gridRoot.Find(gridName);

        if (child != null)
            return child;

        foreach (Transform t in gridRoot.GetComponentsInChildren<Transform>(true))
        {
            if (t.name == gridName)
                return t;
        }

        return null;
    }

    private Transform FindSpawnPoint(Transform grid)
    {
        Transform point = grid.Find(spawnPointName);

        if (point != null)
            return point;

        Debug.LogWarning($"[BattleMonsterSpawner] {grid.name} �ȿ� {spawnPointName} ������Ʈ�� �����ϴ�. Grid ��ġ�� ��� ����մϴ�.");
        return null;
    }

    public SpawnedMonsterResult SpawnRuntimeMonster(string monsterId, List<int> cells)
    {
        if (string.IsNullOrWhiteSpace(monsterId))
            return null;

        if (cells == null || cells.Count <= 0)
            return null;

        var dm = DataManager.Instance;

        if (dm == null || dm.MonsterDatabase == null)
            return null;

        MonsterMasterData monsterData = dm.MonsterDatabase.Get(monsterId);

        if (monsterData == null || monsterData.BattlePrefab == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] MonsterData �Ǵ� BattlePrefab ����: {monsterId}");
            return null;
        }

        int mainCell = cells[0];

        Transform spawnGrid = FindGridByIndex(mainCell);

        if (spawnGrid == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] Grid ������Ʈ ����: Grid_{mainCell:00}");
            return null;
        }

        Transform spawnPoint = FindSpawnPoint(spawnGrid);

        Vector3 spawnPosition = spawnPoint != null
            ? spawnPoint.position
            : spawnGrid.position;

        spawnPosition.z += unitSpawnZOffset;

        GameObject monster = Instantiate(
            monsterData.BattlePrefab,
            spawnPosition,
            Quaternion.identity,
            monsterRoot
        );

        SetMonsterInitialFacingLeft(monster);

        string runtimeId = MonsterRuntimeIdGenerator.Create();
        MonsterRuntimeData runtimeData = new MonsterRuntimeData(runtimeId, monsterData);
        ApplyDisplayNameSuffix(runtimeData);

        MonsterUnit monsterUnit = monster.GetComponent<MonsterUnit>();

        if (monsterUnit == null)
        {
            Debug.LogError($"[BattleMonsterSpawner] MonsterUnit ����: {monster.name}");
            Destroy(monster);
            return null;
        }

        monsterUnit.Initialize(runtimeData);
        monsterUnit.SetOccupiedCells(cells);

        return new SpawnedMonsterResult
        {
            RuntimeData = runtimeData,
            MonsterTransform = monster.transform
        };
    }


    public void ResetDisplayNameSuffixes()
    {
        displayNameSuffixCounters.Clear();
    }

    private void ApplyDisplayNameSuffix(MonsterRuntimeData runtimeData)
    {
        if (runtimeData == null || string.IsNullOrWhiteSpace(runtimeData.MonsterId))
            return;

        string monsterId = runtimeData.MonsterId.Trim();
        displayNameSuffixCounters.TryGetValue(monsterId, out int currentCount);
        displayNameSuffixCounters[monsterId] = currentCount + 1;

        runtimeData.SetDisplaySuffix(ToAlphabeticSuffix(currentCount));
    }

    private static string ToAlphabeticSuffix(int index)
    {
        index = Mathf.Max(0, index);
        string result = string.Empty;

        do
        {
            int letterIndex = index % 26;
            result = (char)('A' + letterIndex) + result;
            index = (index / 26) - 1;
        }
        while (index >= 0);

        return result;
    }

    private void SetMonsterInitialFacingLeft(GameObject monster)
    {
        if (monster == null)
            return;

        BattleUnitFacing facing = monster.GetComponent<BattleUnitFacing>();

        if (facing == null)
        {
            Debug.LogWarning($"[BattleMonsterSpawner] BattleUnitFacing ����: {monster.name}");
            return;
        }

        facing.InitializeIfNeeded();
        facing.FaceRight(false);

        Debug.Log($"[BattleMonsterSpawner] Spawn Facing Left / {monster.name} / IsFacingRight:{facing.IsFacingRight}");
    }
}

