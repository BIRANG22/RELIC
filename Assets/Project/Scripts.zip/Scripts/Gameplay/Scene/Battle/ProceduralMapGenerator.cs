using System.Collections.Generic;
using System.Linq;
using Relic.Gameplay.Battle;
using UnityEngine;

namespace Relic.Gameplay.Data
{
    public static class BattleMapLayoutUtility
    {
        public const float LayerGap = 100f;
        public const float RowGap = 40f;

        public static Vector2 CalculatePosition(int layerIndex, int rowIndex, int rowCount)
        {
            int safeRowCount = Mathf.Max(1, rowCount);
            float centeredRow = rowIndex - (safeRowCount - 1) * 0.5f;
            return new Vector2(layerIndex * LayerGap, -centeredRow * RowGap);
        }

        public static void ApplyHorizontalLayout(List<GeneratedMapNodeData> nodes)
        {
            if (nodes == null)
                return;

            foreach (IGrouping<int, GeneratedMapNodeData> layerGroup in
                     nodes.Where(node => node != null).GroupBy(node => node.LayerIndex))
            {
                List<GeneratedMapNodeData> layer = layerGroup.ToList();
                float minX = layer.Min(node => node.Position.x);
                float maxX = layer.Max(node => node.Position.x);
                bool alreadyHorizontal = maxX - minX < 1f;

                layer.Sort((left, right) => alreadyHorizontal
                    ? right.Position.y.CompareTo(left.Position.y)
                    : left.Position.x.CompareTo(right.Position.x));

                for (int row = 0; row < layer.Count; row++)
                    layer[row].Position = CalculatePosition(layerGroup.Key, row, layer.Count);
            }
        }
    }

    public class ProceduralMapGenerator
    {
        private int nextNodeIndex;

        // Common 맵은 한 번 등장하면 이후 선택 가중치를 낮춥니다.
        // 같은 Common 맵이 2회 연속 등장한 경우에는 더 크게 낮춥니다.
        private readonly Dictionary<string, int> commonMapAppearCounts = new();
        private string lastCommonMapId = string.Empty;
        private int consecutiveCommonMapCount;

        private const float CommonRepeatWeightMultiplier = 0.5f;
        private const float CommonDoubleRepeatWeightMultiplier = 0.2f;

        private const int TotalLayerCount = 10;
        private const int MaxColumnCount = 3;

        private const int MaxOutgoingConnections = 2;
        private const int MaxIncomingConnections = 2;
        private const float MinNodeXDistance = 110f;

        private const int MinTotalNodeCount = 20;
        private const int MaxTotalNodeCount = 24;

        private const float ExtraConnectionChance = 0.60f;
        private const float EdgeExtraConnectionChance = 0.80f;
        private const float EdgeColumnThresholdX = 140f;

        public List<GeneratedMapNodeData> Generate(
            List<MapData> mapPool,
            string chapter,
            string stage)
        {
            return Generate(mapPool, chapter, stage, null);
        }

        public List<GeneratedMapNodeData> Generate(
            List<MapData> mapPool,
            string chapter,
            string stage,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            nextNodeIndex = 0;
            commonMapAppearCounts.Clear();
            lastCommonMapId = string.Empty;
            consecutiveCommonMapCount = 0;

            List<GeneratedMapNodeData> result = new();

            if (mapPool == null || mapPool.Count == 0)
            {
                Debug.LogWarning("[ProceduralMapGenerator] MapPool이 비어 있습니다.");
                return result;
            }

            int[] layerNodeCounts = GenerateValidLayerCounts();

            List<List<GeneratedMapNodeData>> layers = new();

            for (int layer = 0; layer < TotalLayerCount; layer++)
            {
                List<GeneratedMapNodeData> currentLayer = new();

                int nodeCount = layerNodeCounts[layer];
                List<string> layerTypes = DecideLayerTypes(layer, nodeCount, layers);

                for (int i = 0; i < nodeCount; i++)
                {
                    string type = layerTypes[i];

                    MapData mapData = PickMapDataForLayer(
                        mapPool,
                        chapter,
                        stage,
                        layer,
                        type,
                        randomExclusionSettings
                    );

                    if (mapData == null)
                        continue;

                    Vector2 position = CalculatePosition(layer, i, nodeCount);

                    GeneratedMapNodeData node = CreateNode(
                        mapData.MapId,
                        mapData.Type,
                        mapData.EventId,
                        position,
                        layer
                    );

                    currentLayer.Add(node);
                    result.Add(node);
                }

                FixLayerNodeOverlap(currentLayer);
                layers.Add(currentLayer);
            }

            for (int layer = 0; layer < layers.Count - 1; layer++)
            {
                ConnectLayersWithoutCrossing(
                    layers[layer],
                    layers[layer + 1]
                );
            }

            // 서로 직접 연결된 Common 노드는 같은 맵을 사용하지 않습니다.
            // 연결 정보가 완성된 뒤 부모 노드의 맵 ID를 제외하고 다시 선택합니다.
            EnforceConnectedCommonMapUniqueness(
                layers,
                mapPool,
                chapter,
                stage,
                randomExclusionSettings
            );

            return result;
        }

        private int[] GenerateValidLayerCounts()
        {
            for (int attempt = 0; attempt < 500; attempt++)
            {
                int[] counts = new int[TotalLayerCount];

                counts[0] = 1;
                counts[TotalLayerCount - 1] = 1;

                for (int layer = 1; layer < TotalLayerCount - 1; layer++)
                {
                    if (layer == 1)
                    {
                        counts[layer] = 2;
                    }
                    else if (layer == 2)
                    {
                        counts[layer] = 3;
                    }
                    else if (layer == TotalLayerCount - 2)
                    {
                        counts[layer] = 2;
                    }
                    else if (layer == TotalLayerCount - 3)
                    {
                        counts[layer] = 3;
                    }
                    else
                    {
                        counts[layer] = BattleRandom.Range(2, MaxColumnCount + 1);
                    }
                }

                if (!IsValidLayerCountSet(counts))
                    continue;

                int totalNodeCount = 0;

                for (int i = 0; i < counts.Length; i++)
                    totalNodeCount += counts[i];

                if (totalNodeCount < MinTotalNodeCount)
                    continue;

                if (totalNodeCount > MaxTotalNodeCount)
                    continue;

                return counts;
            }

            return new int[]
            {
                1,2,3,3,3,3,3,3,2,1
            };
        }

        private bool IsValidLayerCountSet(int[] counts)
        {
            for (int i = 0; i < counts.Length - 1; i++)
            {
                int previous = counts[i];
                int current = counts[i + 1];

                if (current > previous * MaxOutgoingConnections)
                    return false;

                if (previous > current * MaxIncomingConnections)
                    return false;
            }

            return true;
        }

        private int[] DecideColumns(int layer, int nodeCount)
        {
            if (layer == 0)
                return new int[] { 1 };

            if (layer == 1 && nodeCount == 2)
                return new int[] { 0, 2 };

            if (layer == TotalLayerCount - 3)
            {
                return new int[] { 0, 1, 2 };
            }

            if (layer == TotalLayerCount - 2)
                return new int[] { 0, 2 };

            if (layer == TotalLayerCount - 1)
                return new int[] { 1 };

            List<int> columns = new();

            while (columns.Count < nodeCount)
            {
                int column = BattleRandom.Range(0, MaxColumnCount);

                if (!columns.Contains(column))
                    columns.Add(column);
            }

            columns.Sort();
            return columns.ToArray();
        }

        private Vector2 CalculatePosition(int layer, int row, int rowCount)
        {
            return BattleMapLayoutUtility.CalculatePosition(layer, row, rowCount);
        }

        private void ConnectLayersWithoutCrossing(
            List<GeneratedMapNodeData> previousLayer,
            List<GeneratedMapNodeData> currentLayer)
        {
            if (previousLayer == null || currentLayer == null)
                return;

            if (previousLayer.Count == 0 || currentLayer.Count == 0)
                return;

            previousLayer.Sort((a, b) => a.Position.y.CompareTo(b.Position.y));
            currentLayer.Sort((a, b) => a.Position.y.CompareTo(b.Position.y));

            Dictionary<int, int> outgoingCount = new();
            Dictionary<int, int> incomingCount = new();

            for (int i = 0; i < previousLayer.Count; i++)
                outgoingCount[previousLayer[i].NodeIndex] = 0;

            for (int i = 0; i < currentLayer.Count; i++)
                incomingCount[currentLayer[i].NodeIndex] = 0;

            BuildMainNonCrossingConnections(
                previousLayer,
                currentLayer,
                outgoingCount,
                incomingCount
            );

            AddBalancedExtraConnections(
                previousLayer,
                currentLayer,
                outgoingCount,
                incomingCount
            );

            ClampCurrentLayerXInsideParents(previousLayer, currentLayer);
        }

        private void BuildMainNonCrossingConnections(
            List<GeneratedMapNodeData> previousLayer,
            List<GeneratedMapNodeData> currentLayer,
            Dictionary<int, int> outgoingCount,
            Dictionary<int, int> incomingCount)
        {
            for (int previousIndex = 0; previousIndex < previousLayer.Count; previousIndex++)
            {
                int currentIndex = Mathf.FloorToInt(
                    (float)previousIndex * currentLayer.Count / previousLayer.Count
                );

                currentIndex = Mathf.Clamp(currentIndex, 0, currentLayer.Count - 1);

                AddLimitedConnection(
                    previousLayer[previousIndex],
                    currentLayer[currentIndex],
                    outgoingCount,
                    incomingCount
                );
            }

            for (int currentIndex = 0; currentIndex < currentLayer.Count; currentIndex++)
            {
                GeneratedMapNodeData current = currentLayer[currentIndex];

                if (incomingCount[current.NodeIndex] > 0)
                    continue;

                int previousIndex = Mathf.FloorToInt(
                    (float)currentIndex * previousLayer.Count / currentLayer.Count
                );

                previousIndex = Mathf.Clamp(previousIndex, 0, previousLayer.Count - 1);

                AddLimitedConnection(
                    previousLayer[previousIndex],
                    current,
                    outgoingCount,
                    incomingCount
                );
            }
        }

        private void AddBalancedExtraConnections(
            List<GeneratedMapNodeData> previousLayer,
            List<GeneratedMapNodeData> currentLayer,
            Dictionary<int, int> outgoingCount,
            Dictionary<int, int> incomingCount)
        {
            for (int previousIndex = 0; previousIndex < previousLayer.Count; previousIndex++)
            {
                GeneratedMapNodeData from = previousLayer[previousIndex];

                if (outgoingCount[from.NodeIndex] >= MaxOutgoingConnections)
                    continue;

                float chance = ExtraConnectionChance;

                if (Mathf.Abs(from.Position.y) >= EdgeColumnThresholdX)
                    chance = EdgeExtraConnectionChance;

                if (BattleRandom.Value() > chance)
                    continue;

                int leftIndex = FindNearestCurrentIndexOnSide(
                    from,
                    currentLayer,
                    incomingCount,
                    true
                );

                int rightIndex = FindNearestCurrentIndexOnSide(
                    from,
                    currentLayer,
                    incomingCount,
                    false
                );

                if (leftIndex < 0 || rightIndex < 0)
                    continue;

                if (WouldCrossExistingConnections(previousLayer, currentLayer, previousIndex, leftIndex))
                    continue;

                if (WouldCrossExistingConnections(previousLayer, currentLayer, previousIndex, rightIndex))
                    continue;

                int connectedIndex = GetConnectedCurrentIndex(from, currentLayer);

                if (connectedIndex >= 0)
                {
                    float connectedX = currentLayer[connectedIndex].Position.y;

                    if (connectedX < from.Position.y)
                    {
                        AddLimitedConnection(
                            from,
                            currentLayer[rightIndex],
                            outgoingCount,
                            incomingCount
                        );
                    }
                    else if (connectedX > from.Position.y)
                    {
                        AddLimitedConnection(
                            from,
                            currentLayer[leftIndex],
                            outgoingCount,
                            incomingCount
                        );
                    }
                    else
                    {
                        int targetIndex = BattleRandom.Value() < 0.5f ? leftIndex : rightIndex;

                        AddLimitedConnection(
                            from,
                            currentLayer[targetIndex],
                            outgoingCount,
                            incomingCount
                        );
                    }
                }
            }
        }

        private int FindNearestCurrentIndexOnSide(
            GeneratedMapNodeData from,
            List<GeneratedMapNodeData> currentLayer,
            Dictionary<int, int> incomingCount,
            bool leftSide)
        {
            int bestIndex = -1;
            float bestDistance = float.MaxValue;

            for (int i = 0; i < currentLayer.Count; i++)
            {
                GeneratedMapNodeData candidate = currentLayer[i];

                if (incomingCount[candidate.NodeIndex] >= MaxIncomingConnections)
                    continue;

                if (from.NextNodeIndices.Contains(candidate.NodeIndex))
                    continue;

                bool isLeft = candidate.Position.y < from.Position.y;
                bool isRight = candidate.Position.y > from.Position.y;

                if (leftSide && !isLeft)
                    continue;

                if (!leftSide && !isRight)
                    continue;

                float distance = Mathf.Abs(candidate.Position.y - from.Position.y);

                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    bestIndex = i;
                }
            }

            return bestIndex;
        }

        private void AddLimitedConnection(
            GeneratedMapNodeData from,
            GeneratedMapNodeData to,
            Dictionary<int, int> outgoingCount,
            Dictionary<int, int> incomingCount)
        {
            if (from == null || to == null)
                return;

            if (from.NextNodeIndices.Contains(to.NodeIndex))
                return;

            if (outgoingCount[from.NodeIndex] >= MaxOutgoingConnections)
                return;

            if (incomingCount[to.NodeIndex] >= MaxIncomingConnections)
                return;

            from.NextNodeIndices.Add(to.NodeIndex);
            outgoingCount[from.NodeIndex]++;
            incomingCount[to.NodeIndex]++;
        }

        private void ClampCurrentLayerXInsideParents(
            List<GeneratedMapNodeData> previousLayer,
            List<GeneratedMapNodeData> currentLayer)
        {
            for (int i = 0; i < currentLayer.Count; i++)
            {
                GeneratedMapNodeData current = currentLayer[i];

                float minParentX = float.MaxValue;
                float maxParentX = float.MinValue;
                int parentCount = 0;

                for (int p = 0; p < previousLayer.Count; p++)
                {
                    GeneratedMapNodeData parent = previousLayer[p];

                    if (!parent.NextNodeIndices.Contains(current.NodeIndex))
                        continue;

                    minParentX = Mathf.Min(minParentX, parent.Position.y);
                    maxParentX = Mathf.Max(maxParentX, parent.Position.y);
                    parentCount++;
                }

                if (parentCount < 2)
                    continue;

                Vector2 position = current.Position;
                position.y = Mathf.Clamp(position.y, minParentX, maxParentX);
                current.Position = position;
            }
        }


        private void EnforceConnectedCommonMapUniqueness(
            List<List<GeneratedMapNodeData>> layers,
            List<MapData> mapPool,
            string chapter,
            string stage,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            if (layers == null || mapPool == null)
                return;

            for (int layerIndex = 1; layerIndex < layers.Count; layerIndex++)
            {
                List<GeneratedMapNodeData> previousLayer = layers[layerIndex - 1];
                List<GeneratedMapNodeData> currentLayer = layers[layerIndex];

                if (previousLayer == null || currentLayer == null)
                    continue;

                for (int nodeIndex = 0; nodeIndex < currentLayer.Count; nodeIndex++)
                {
                    GeneratedMapNodeData currentNode = currentLayer[nodeIndex];

                    if (currentNode == null || currentNode.Type != "Common")
                        continue;

                    HashSet<string> connectedParentCommonMapIds = new();

                    for (int parentIndex = 0; parentIndex < previousLayer.Count; parentIndex++)
                    {
                        GeneratedMapNodeData parentNode = previousLayer[parentIndex];

                        if (parentNode == null || parentNode.Type != "Common")
                            continue;

                        if (!parentNode.NextNodeIndices.Contains(currentNode.NodeIndex))
                            continue;

                        if (!string.IsNullOrEmpty(parentNode.MapId))
                            connectedParentCommonMapIds.Add(parentNode.MapId);
                    }

                    if (!connectedParentCommonMapIds.Contains(currentNode.MapId))
                        continue;

                    List<MapData> alternatives = new();

                    for (int mapIndex = 0; mapIndex < mapPool.Count; mapIndex++)
                    {
                        MapData candidate = mapPool[mapIndex];

                        if (candidate == null)
                            continue;

                        if (candidate.Stage != stage)
                            continue;

                        if (candidate.Type != "Common")
                            continue;

                        if (!IsRandomCandidateAllowed(candidate, randomExclusionSettings))
                            continue;

                        if (connectedParentCommonMapIds.Contains(candidate.MapId))
                            continue;

                        alternatives.Add(candidate);
                    }

                    // 대체 가능한 Common 맵이 하나도 없다면 기존 맵을 유지합니다.
                    if (alternatives.Count == 0)
                        continue;

                    DecreaseCommonMapAppearCount(currentNode.MapId);

                    MapData replacement = PickCommonMapByWeight(alternatives);

                    if (replacement == null)
                        continue;

                    currentNode.MapId = replacement.MapId;
                    currentNode.Type = replacement.Type;
                    currentNode.EventId = EventIdUtility.Normalize(replacement.EventId);
                    RecordCommonMapSelection(replacement);
                }
            }
        }

        private void DecreaseCommonMapAppearCount(string mapId)
        {
            if (string.IsNullOrEmpty(mapId))
                return;

            if (!commonMapAppearCounts.TryGetValue(mapId, out int appearCount))
                return;

            if (appearCount <= 1)
            {
                commonMapAppearCounts.Remove(mapId);
                return;
            }

            commonMapAppearCounts[mapId] = appearCount - 1;
        }

        private MapData PickMapDataForLayer(
           List<MapData> mapPool,
            string chapter,
            string stage,
            int layer,
            string decidedType,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            if (layer == 0)
            {
                MapData startMap = PickRandomMapData(
                    mapPool,
                    chapter,
                    stage,
                    "Start",
                    randomExclusionSettings
                );

                if (startMap != null)
                    return startMap;

                return CreateVirtualMapData("Start", "Start");
            }

            if (layer == TotalLayerCount - 1)
                return PickRandomMapData(mapPool, chapter, stage, "Boss", randomExclusionSettings);

            return PickRandomMapData(
                mapPool,
                chapter,
                stage,
                decidedType,
                randomExclusionSettings
            );
        }

        private string DecideRandomType(string previousType = "")
        {
            float eventChance = 0.35f;

            if (previousType == "Common")
                eventChance += 0.25f;

            if (previousType == "Special")
                eventChance -= 0.25f;

            eventChance = Mathf.Clamp01(eventChance);

            return BattleRandom.Value() < eventChance
                ? "Special"
                : "Common";
        }

        private MapData PickRandomMapData(
            List<MapData> mapPool,
            string chapter,
            string stage,
            string type,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            List<MapData> candidates = new();

            for (int i = 0; i < mapPool.Count; i++)
            {
                MapData data = mapPool[i];

                if (data == null)
                    continue;

                if (data.Stage != stage)
                    continue;

                if (data.Type != type)
                    continue;

                // 일반 Special 노드에는 실제 랜덤 이벤트 풀만 사용합니다.
                // Map_19(Event_03), Map_22(Event_06 상점), Map_25(Event_09 시작방)는 제외됩니다.
                if (type == "Special" && !MapRoomSelectionResolver.IsNormalRandomEventMap(data))
                    continue;

                if (!IsRandomCandidateAllowed(data, randomExclusionSettings))
                    continue;

                candidates.Add(data);
            }

            if (candidates.Count == 0 && !IsReservedMapType(type))
                return PickAnyNormalMap(mapPool, chapter, stage, randomExclusionSettings);

            if (candidates.Count == 0)
                return null;

            if (type == "Common")
            {
                MapData selectedCommonMap = PickCommonMapByWeight(candidates);
                RecordCommonMapSelection(selectedCommonMap);
                return selectedCommonMap;
            }

            return PickByWeight(candidates);
        }

        private MapData PickAnyNormalMap(
            List<MapData> mapPool,
            string chapter,
            string stage,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            List<MapData> candidates = new();

            for (int i = 0; i < mapPool.Count; i++)
            {
                MapData data = mapPool[i];

                if (data == null)
                    continue;

                if (data.Stage != stage)
                    continue;

                if (IsReservedMapType(data.Type))
                    continue;

                if (!IsRandomCandidateAllowed(data, randomExclusionSettings))
                    continue;

                candidates.Add(data);
            }

            if (candidates.Count == 0)
                return null;

            return PickByWeight(candidates);
        }


        private MapData PickCommonMapByWeight(List<MapData> candidates)
        {
            if (candidates == null || candidates.Count == 0)
                return null;

            float totalWeight = 0f;

            for (int i = 0; i < candidates.Count; i++)
                totalWeight += GetCommonMapAdjustedWeight(candidates[i]);

            if (totalWeight <= 0f)
                return candidates[BattleRandom.Range(0, candidates.Count)];

            float random = BattleRandom.Range(0f, totalWeight);
            float current = 0f;

            for (int i = 0; i < candidates.Count; i++)
            {
                current += GetCommonMapAdjustedWeight(candidates[i]);

                if (random < current)
                    return candidates[i];
            }

            return candidates[candidates.Count - 1];
        }

        private float GetCommonMapAdjustedWeight(MapData candidate)
        {
            if (candidate == null)
                return 0f;

            float weight = Mathf.Max(0, candidate.SpawnWeight);

            if (commonMapAppearCounts.TryGetValue(candidate.MapId, out int appearCount) && appearCount > 0)
                weight *= CommonRepeatWeightMultiplier;

            if (candidate.MapId == lastCommonMapId && consecutiveCommonMapCount >= 2)
                weight *= CommonDoubleRepeatWeightMultiplier / CommonRepeatWeightMultiplier;

            return weight;
        }

        private void RecordCommonMapSelection(MapData selectedMap)
        {
            if (selectedMap == null || string.IsNullOrEmpty(selectedMap.MapId))
                return;

            if (commonMapAppearCounts.TryGetValue(selectedMap.MapId, out int appearCount))
                commonMapAppearCounts[selectedMap.MapId] = appearCount + 1;
            else
                commonMapAppearCounts[selectedMap.MapId] = 1;

            if (lastCommonMapId == selectedMap.MapId)
            {
                consecutiveCommonMapCount++;
                return;
            }

            lastCommonMapId = selectedMap.MapId;
            consecutiveCommonMapCount = 1;
        }

        private MapData PickByWeight(List<MapData> candidates)
        {
            int totalWeight = 0;

            for (int i = 0; i < candidates.Count; i++)
                totalWeight += Mathf.Max(0, candidates[i].SpawnWeight);

            if (totalWeight <= 0)
                return candidates[BattleRandom.Range(0, candidates.Count)];

            int random = BattleRandom.Range(0, totalWeight);
            int current = 0;

            for (int i = 0; i < candidates.Count; i++)
            {
                current += Mathf.Max(0, candidates[i].SpawnWeight);

                if (random < current)
                    return candidates[i];
            }

            return candidates[0];
        }

        private void FixLayerNodeOverlap(List<GeneratedMapNodeData> layer)
        {
            if (layer == null || layer.Count <= 1)
                return;

            layer.Sort((a, b) => a.Position.y.CompareTo(b.Position.y));

            for (int i = 1; i < layer.Count; i++)
            {
                GeneratedMapNodeData left = layer[i - 1];
                GeneratedMapNodeData right = layer[i];

                float distance = right.Position.y - left.Position.y;

                if (distance >= MinNodeXDistance)
                    continue;

                float lack = MinNodeXDistance - distance;
                float half = lack * 0.5f;

                Vector2 leftPos = left.Position;
                Vector2 rightPos = right.Position;

                leftPos.y -= half;
                rightPos.y += half;

                left.Position = leftPos;
                right.Position = rightPos;
            }

            ClampLayerInsideMapWidth(layer);
        }

        private void ClampLayerInsideMapWidth(List<GeneratedMapNodeData> layer)
        {
            float maxX = ((MaxColumnCount - 1) * 0.5f) * BattleMapLayoutUtility.RowGap;
            float minX = -maxX;

            for (int i = 0; i < layer.Count; i++)
            {
                Vector2 position = layer[i].Position;

                position.y = Mathf.Clamp(position.y, minX, maxX);

                layer[i].Position = position;
            }
        }

        private MapData CreateVirtualMapData(string mapId, string type)
        {
            return new MapData
            {
                MapId = mapId,
                Name = mapId,
                Type = type,
                EventId = string.Empty,
                SpawnWeight = 1
            };
        }

        private bool IsReservedMapType(string type)
        {
            return type == "Start" || type == "Boss";
        }

        private static bool IsRandomCandidateAllowed(
            MapData candidate,
            EventMapRandomExclusionSettings randomExclusionSettings)
        {
            return randomExclusionSettings == null ||
                   randomExclusionSettings.IsMapAllowedForRandomSelection(candidate);
        }

        private bool WouldCrossExistingConnections(
            List<GeneratedMapNodeData> previousLayer,
            List<GeneratedMapNodeData> currentLayer,
            int fromIndex,
            int toIndex)
        {
            for (int i = 0; i < previousLayer.Count; i++)
            {
                GeneratedMapNodeData otherFrom = previousLayer[i];

                for (int j = 0; j < otherFrom.NextNodeIndices.Count; j++)
                {
                    int otherToIndex = FindLayerIndexByNodeIndex(
                        currentLayer,
                        otherFrom.NextNodeIndices[j]
                    );

                    if (otherToIndex < 0)
                        continue;

                    if (i == fromIndex)
                        continue;

                    if (fromIndex < i && toIndex > otherToIndex)
                        return true;

                    if (fromIndex > i && toIndex < otherToIndex)
                        return true;
                }
            }

            return false;
        }

        private int GetConnectedCurrentIndex(
            GeneratedMapNodeData from,
            List<GeneratedMapNodeData> currentLayer)
        {
            for (int i = 0; i < currentLayer.Count; i++)
            {
                if (from.NextNodeIndices.Contains(currentLayer[i].NodeIndex))
                    return i;
            }

            return -1;
        }

        private int FindLayerIndexByNodeIndex(
            List<GeneratedMapNodeData> layer,
            int nodeIndex)
        {
            for (int i = 0; i < layer.Count; i++)
            {
                if (layer[i].NodeIndex == nodeIndex)
                    return i;
            }

            return -1;
        }

        private GeneratedMapNodeData CreateNode(
            string mapId,
            string type,
            string eventId,
            Vector2 position,
            int layerIndex)
        {
            return new GeneratedMapNodeData
            {
                NodeIndex = nextNodeIndex++,
                LayerIndex = layerIndex,
                MapId = mapId,
                Type = type,
                EventId = EventIdUtility.Normalize(eventId),
                Position = position
            };
        }

        private List<string> DecideLayerTypes(
            int layer,
            int nodeCount,
            List<List<GeneratedMapNodeData>> previousLayers)
        {
            List<string> result = new();

            if (layer == 0)
            {
                result.Add("Start");
                return result;
            }

            if (layer == 1)
            {
                for (int i = 0; i < nodeCount; i++)
                    result.Add("Common");

                return result;
            }

            if (layer == TotalLayerCount - 1)
            {
                result.Add("Boss");
                return result;
            }

            if (layer == TotalLayerCount - 2)
            {
                for (int i = 0; i < nodeCount; i++)
                    result.Add("Rest");

                return result;
            }

            if (layer == TotalLayerCount - 3)
            {
                result.Add("Elite");
                result.Add("Common");

                while (result.Count < nodeCount)
                    result.Add(BattleRandom.Value() < 0.5f ? "Elite" : "Common");

                ShuffleStrings(result);
                return result;
            }

            for (int i = 0; i < nodeCount; i++)
            {
                string previousType = GetRandomPreviousLayerType(previousLayers);
                result.Add(DecideRandomType(previousType));
            }

            return result;
        }

        private string GetRandomPreviousLayerType(
            List<List<GeneratedMapNodeData>> previousLayers)
        {
            if (previousLayers == null || previousLayers.Count <= 0)
                return "";

            List<GeneratedMapNodeData> previousLayer =
                previousLayers[previousLayers.Count - 1];

            if (previousLayer == null || previousLayer.Count <= 0)
                return "";

            GeneratedMapNodeData node =
                previousLayer[BattleRandom.Range(0, previousLayer.Count)];

            return node != null ? node.Type : "";
        }

        private void ShuffleStrings(List<string> list)
        {
            if (list == null)
                return;

            for (int i = 0; i < list.Count; i++)
            {
                int randomIndex = BattleRandom.Range(i, list.Count);
                (list[i], list[randomIndex]) = (list[randomIndex], list[i]);
            }
        }
    }
}
