using System;
using System.Collections.Generic;
using UnityEngine;

namespace Relic.Gameplay.Data
{
    public enum SkillAttackSlot
    {
        None = 0,

        Attack1 = 1,
        Attack2 = 2,
        Attack3 = 3,

        Power = 4,
        Skill = 5,

        Extra1 = 6,
        Extra2 = 7,
        Extra3 = 8,
        Extra4 = 9,
        Extra5 = 10
    }

    [CreateAssetMenu(menuName = "Relic/Data/Skill Attack Override Database")]
    public class SkillAttackOverrideDatabase : ScriptableObject
    {
        [SerializeField] private List<SkillAttackOverrideEntry> entries = new();

        private Dictionary<string, SkillAttackOverrideEntry> map;

        public void Initialize()
        {
            map = new Dictionary<string, SkillAttackOverrideEntry>();

            foreach (SkillAttackOverrideEntry entry in entries)
            {
                if (entry == null)
                    continue;

                string characterId = NormalizeId(entry.CharacterId);
                string skillId = NormalizeId(entry.SkillId);

                if (string.IsNullOrWhiteSpace(characterId) ||
                    string.IsNullOrWhiteSpace(skillId) ||
                    entry.AttackSlot == SkillAttackSlot.None)
                {
                    continue;
                }

                string key = MakeKey(characterId, skillId);

                if (map.ContainsKey(key))
                {
                    Debug.LogWarning(
                        $"[SkillAttackOverrideDatabase] Duplicate override: {characterId} / {skillId}");
                    continue;
                }

                map.Add(key, entry);
            }
        }

        public bool TryGetPresentationSlot(
            string characterId,
            string skillId,
            out SkillAttackSlot slot)
        {
            slot = SkillAttackSlot.None;

            if (!TryGetEntry(characterId, skillId, out SkillAttackOverrideEntry entry))
                return false;

            slot = entry.AttackSlot;
            return slot != SkillAttackSlot.None;
        }

        /// <summary>
        /// 2Ÿ ���� ����� ���� �ִϸ��̼� ������ ��ȯ�մϴ�.
        /// ���� Ÿ�ݿ��� ����� ������ ������ ��� �����մϴ�.
        /// </summary>
        public bool TryGetRepeatPresentationSlot(
            string characterId,
            string skillId,
            SkillAttackSlot previousSlot,
            out SkillAttackSlot slot)
        {
            slot = SkillAttackSlot.None;

            if (!TryGetEntry(characterId, skillId, out SkillAttackOverrideEntry entry))
                return false;

            List<SkillAttackSlot> repeatSlots = entry.RepeatAttackSlots;

            if (repeatSlots == null || repeatSlots.Count == 0)
            {
                // �ݺ� �ִϰ� �������� ���� ���� �����ʹ�
                // ���� AttackSlot�� �״�� ����մϴ�.
                slot = entry.AttackSlot;
                return slot != SkillAttackSlot.None;
            }

            List<SkillAttackSlot> validSlots = new();

            for (int i = 0; i < repeatSlots.Count; i++)
            {
                SkillAttackSlot candidate = repeatSlots[i];

                if (candidate == SkillAttackSlot.None)
                    continue;

                // �ٷ� ���� Ÿ�� �ִϸ��̼��� ����
                if (candidate == previousSlot)
                    continue;

                // ���� ������ ����Ʈ�� �ߺ� ��ϵǾ� �־ �� ���� �ĺ��� �߰�
                if (!validSlots.Contains(candidate))
                    validSlots.Add(candidate);
            }

            if (validSlots.Count > 0)
            {
                slot = validSlots[UnityEngine.Random.Range(0, validSlots.Count)];
                return true;
            }

            // �ĺ��� �ϳ����̰� �װ� ���� �ִ��� ��� ��
            // ������ �� �ƹ��͵� ���� ������ �ݺ� ����Ʈ���� �ٽ� ����
            validSlots.Clear();

            for (int i = 0; i < repeatSlots.Count; i++)
            {
                SkillAttackSlot candidate = repeatSlots[i];

                if (candidate == SkillAttackSlot.None)
                    continue;

                if (!validSlots.Contains(candidate))
                    validSlots.Add(candidate);
            }

            if (validSlots.Count > 0)
            {
                slot = validSlots[UnityEngine.Random.Range(0, validSlots.Count)];
                return true;
            }

            // ����Ʈ�� None�� ����ִ� ���
            slot = entry.AttackSlot;
            return slot != SkillAttackSlot.None;
        }

        public bool TryGetAttackSlot(
            string characterId,
            string skillId,
            out SkillAttackSlot attackSlot)
        {
            return TryGetPresentationSlot(characterId, skillId, out attackSlot);
        }

        public bool TryGetAttackIndex(
            string characterId,
            string skillId,
            out int attackIndex)
        {
            attackIndex = 0;

            if (!TryGetPresentationSlot(
                    characterId,
                    skillId,
                    out SkillAttackSlot slot))
            {
                return false;
            }

            if (slot < SkillAttackSlot.Attack1 ||
                slot > SkillAttackSlot.Attack3)
            {
                return false;
            }

            attackIndex = (int)slot;
            return true;
        }

        private bool TryGetEntry(
            string characterId,
            string skillId,
            out SkillAttackOverrideEntry entry)
        {
            entry = null;

            characterId = NormalizeId(characterId);
            skillId = NormalizeId(skillId);

            if (string.IsNullOrWhiteSpace(characterId) ||
                string.IsNullOrWhiteSpace(skillId))
            {
                return false;
            }

            if (map == null)
                Initialize();

            return map.TryGetValue(
                MakeKey(characterId, skillId),
                out entry);
        }

        private static string NormalizeId(string id)
        {
            return string.IsNullOrWhiteSpace(id)
                ? string.Empty
                : id.Trim();
        }

        private static string MakeKey(
            string characterId,
            string skillId)
        {
            return $"{characterId}\n{skillId}";
        }
    }

    [Serializable]
    public class SkillAttackOverrideEntry
    {
        public string CharacterId;

        public string SkillId;

        [Tooltip("ù ��° Ÿ�ݿ��� ����� �ִϸ��̼�")]
        public SkillAttackSlot AttackSlot = SkillAttackSlot.None;

        [Tooltip("2��° Ÿ�ݺ��� �������� ����� �ִϸ��̼� ���")]
        public List<SkillAttackSlot> RepeatAttackSlots = new();
    }
}

#if UNITY_EDITOR
namespace Relic.Gameplay.Data
{
    [UnityEditor.CustomPropertyDrawer(typeof(SkillAttackOverrideEntry))]
    public class SkillAttackOverrideEntryDrawer : UnityEditor.PropertyDrawer
    {
        private const float Spacing = 2f;

        public override void OnGUI(
            Rect position,
            UnityEditor.SerializedProperty property,
            GUIContent label)
        {
            UnityEditor.SerializedProperty skillIdProperty =
                property.FindPropertyRelative("SkillId");

            string skillId =
                skillIdProperty != null
                    ? skillIdProperty.stringValue?.Trim()
                    : string.Empty;

            string displayName =
                string.IsNullOrEmpty(skillId)
                    ? label.text
                    : skillId;

            UnityEditor.EditorGUI.BeginProperty(
                position,
                label,
                property);

            float lineHeight =
                UnityEditor.EditorGUIUtility.singleLineHeight;

            Rect foldoutRect = new Rect(
                position.x,
                position.y,
                position.width,
                lineHeight);

            property.isExpanded =
                UnityEditor.EditorGUI.Foldout(
                    foldoutRect,
                    property.isExpanded,
                    new GUIContent(displayName),
                    true);

            if (property.isExpanded)
            {
                int previousIndent =
                    UnityEditor.EditorGUI.indentLevel;

                UnityEditor.EditorGUI.indentLevel =
                    previousIndent + 1;

                float y =
                    foldoutRect.yMax + Spacing;

                DrawProperty(
                    property,
                    "CharacterId",
                    position.x,
                    ref y,
                    position.width);

                DrawProperty(
                    property,
                    "SkillId",
                    position.x,
                    ref y,
                    position.width);

                DrawProperty(
                    property,
                    "AttackSlot",
                    position.x,
                    ref y,
                    position.width);

                DrawProperty(
                    property,
                    "RepeatAttackSlots",
                    position.x,
                    ref y,
                    position.width,
                    true);

                UnityEditor.EditorGUI.indentLevel =
                    previousIndent;
            }

            UnityEditor.EditorGUI.EndProperty();
        }

        public override float GetPropertyHeight(
            UnityEditor.SerializedProperty property,
            GUIContent label)
        {
            float lineHeight =
                UnityEditor.EditorGUIUtility.singleLineHeight;

            if (!property.isExpanded)
                return lineHeight;

            float height = lineHeight + Spacing;

            height += GetHeight(property, "CharacterId");
            height += GetHeight(property, "SkillId");
            height += GetHeight(property, "AttackSlot");
            height += GetHeight(
                property,
                "RepeatAttackSlots",
                true);

            return height;
        }

        private static float GetHeight(
            UnityEditor.SerializedProperty parent,
            string propertyName,
            bool includeChildren = false)
        {
            UnityEditor.SerializedProperty child =
                parent.FindPropertyRelative(propertyName);

            if (child == null)
                return 0f;

            return UnityEditor.EditorGUI.GetPropertyHeight(
                       child,
                       includeChildren)
                   + Spacing;
        }

        private static void DrawProperty(
            UnityEditor.SerializedProperty parent,
            string propertyName,
            float x,
            ref float y,
            float width,
            bool includeChildren = false)
        {
            UnityEditor.SerializedProperty child =
                parent.FindPropertyRelative(propertyName);

            if (child == null)
                return;

            float height =
                UnityEditor.EditorGUI.GetPropertyHeight(
                    child,
                    includeChildren);

            Rect rect =
                new Rect(
                    x,
                    y,
                    width,
                    height);

            UnityEditor.EditorGUI.PropertyField(
                rect,
                child,
                includeChildren);

            y += height + Spacing;
        }
    }
}
#endif