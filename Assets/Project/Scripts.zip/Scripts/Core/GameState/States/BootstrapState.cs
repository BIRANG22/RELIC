using System.Threading.Tasks;
using UnityEngine;

public class BootstrapState : BaseGameState
{
    public override GameStateType StateType => GameStateType.Bootstrap;

    public BootstrapState(SceneFlowManager sceneFlow) : base(sceneFlow) { }

    public override async Task Enter(GameStateContext context)
    {
        Debug.Log("[BootstrapState] Enter");

        await sceneFlow.LoadSceneAsync(SceneName.Bootstrap);

        context.ClearRunData();

        // ���⼭ ���߿�
        // - ���̺� �ε�
        // - Addressables �ʱ�ȭ
        // - �۷ι� �ý��� �ʱ�ȭ
        // ���� �߰��ϸ� ��.

        //await GameManager.Instance.StateMachine.ChangeState(GameStateType.Lobby);
    }

    public override Task Exit()
    {
        Debug.Log("[BootstrapState] Exit");
        return Task.CompletedTask;
    }
}