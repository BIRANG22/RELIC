using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneFlowManager : Singleton<SceneFlowManager>
{
    [Header("Scene Transition")]
    [SerializeField] private bool useSceneTransition = true;
    [SerializeField] private bool playTransitionOnFirstLoad = false;

    public string CurrentScene => SceneManager.GetActiveScene().name;
    public bool IsLoading => isLoading;

    private bool isLoading;
    private bool hasLoadedSceneOnce;
    private bool transitionAlreadyClosedForNextLoad;

    protected override void Awake()
    {
        base.Awake();

        if (IsDuplicateInstance)
        {
            return;
        }
    }

    public void LoadScene(string sceneName)
    {
        if (isLoading)
        {
            Debug.LogWarning($"[SceneFlowManager] Already loading scene. Ignored: {sceneName}");
            return;
        }

        if (string.IsNullOrWhiteSpace(sceneName))
        {
            Debug.LogError("[SceneFlowManager] sceneName is null or empty.");
            return;
        }

        if (CurrentScene == sceneName)
        {
            Debug.Log($"[SceneFlowManager] Scene already loaded: {sceneName}");
            transitionAlreadyClosedForNextLoad = false;
            hasLoadedSceneOnce = true;
            return;
        }

        isLoading = true;

        Debug.Log($"[SceneFlowManager] Loading scene: {sceneName}");
        SceneManager.LoadScene(sceneName);

        transitionAlreadyClosedForNextLoad = false;
        hasLoadedSceneOnce = true;
        isLoading = false;
        Debug.Log($"[SceneFlowManager] Loaded scene: {sceneName}");
    }

    public async Task LoadSceneAsync(string sceneName)
    {
        if (isLoading)
        {
            Debug.LogWarning($"[SceneFlowManager] Already loading scene. Ignored: {sceneName}");
            return;
        }

        if (string.IsNullOrWhiteSpace(sceneName))
        {
            Debug.LogError("[SceneFlowManager] sceneName is null or empty.");
            return;
        }

        if (CurrentScene == sceneName)
        {
            Debug.Log($"[SceneFlowManager] Scene already loaded: {sceneName}");
            transitionAlreadyClosedForNextLoad = false;
            hasLoadedSceneOnce = true;
            return;
        }

        isLoading = true;

        CanvasMaterialSceneTransition transition = GetSceneTransition();
        bool continueFromClosedTransition = transitionAlreadyClosedForNextLoad &&
                                            useSceneTransition &&
                                            transition != null;

        transitionAlreadyClosedForNextLoad = false;

        bool shouldPlayTransition = continueFromClosedTransition || ShouldPlayTransition(transition);

        if (shouldPlayTransition && !continueFromClosedTransition)
        {
            await transition.PlayCloseAsync();
            await Task.Yield();
        }

        AsyncOperation loadOperation = SceneManager.LoadSceneAsync(sceneName);

        if (loadOperation == null)
        {
            Debug.LogError($"[SceneFlowManager] Failed to load scene: {sceneName}");

            if (continueFromClosedTransition && transition != null)
                await transition.PlayOpenAsync();

            isLoading = false;
            return;
        }

        loadOperation.allowSceneActivation = true;

        while (!loadOperation.isDone)
        {
            await Task.Yield();
        }

        hasLoadedSceneOnce = true;

        if (shouldPlayTransition)
        {
            await transition.HoldClosedAsync();
            await transition.PlayOpenAsync();
        }

        isLoading = false;
        Debug.Log($"[SceneFlowManager] Loaded scene: {sceneName}");
    }

    /// <summary>
    /// ���� �񵿱� �� �ε尡 �̹� ���� ��ȯ ȭ�鿡�� �����ϵ��� �����մϴ�.
    /// ��Ʈ��ó�� �� ���̿� ���� ȭ���� ���� ���� ��, ���� ������ �ߺ� ������� �ʰ�
    /// �״�� ���� ���� �ε��� �� ���� ���⸸ �̾ ����� �� ����մϴ�.
    /// </summary>
    public void UseAlreadyClosedTransitionForNextLoad()
    {
        CanvasMaterialSceneTransition transition = GetSceneTransition();

        if (!useSceneTransition || transition == null)
        {
            transitionAlreadyClosedForNextLoad = false;
            return;
        }

        transitionAlreadyClosedForNextLoad = true;
    }

    private CanvasMaterialSceneTransition GetSceneTransition()
    {
        if (CanvasMaterialSceneTransition.Instance != null)
        {
            return CanvasMaterialSceneTransition.Instance;
        }

        return FindFirstObjectByType<CanvasMaterialSceneTransition>(FindObjectsInactive.Include);
    }

    private bool ShouldPlayTransition(CanvasMaterialSceneTransition transition)
    {
        if (!useSceneTransition)
        {
            return false;
        }

        if (transition == null)
        {
            Debug.LogWarning("[SceneFlowManager] Scene transition is enabled, but CanvasMaterialSceneTransition was not found.");
            return false;
        }

        // Bootstrap���� Title ���� ���� �ҷ����� ������
        // Title -> Lobby �̵��� SceneFlowManager ���� ù �ε�� �����˴ϴ�.
        // Ÿ��Ʋ���� �����ϴ� ù �� �̵��� �������� ������� ��ȯ ȿ���� ����մϴ�.
        if (!hasLoadedSceneOnce &&
            !playTransitionOnFirstLoad &&
            CurrentScene != SceneName.Title)
        {
            return false;
        }

        return true;
    }
}
