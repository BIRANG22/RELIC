using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;

/// <summary>
/// 데이터 바인딩이나 런타임 프리팹이 TMP 문자열을 직접 대입해도,
/// Text 표의 한국어 원문과 일치하면 즉시 LocalizedTMPText로 전환합니다.
/// </summary>
public static class RuntimeTMPTextAutoLocalizer
{
    private static LocalizationBindingResolver resolver = new(Array.Empty<LocalizationBindingEntry>());
    private static readonly HashSet<int> ProcessingTextIds = new();
    private static readonly HashSet<int> SceneStartupTextIds = new();
    private static bool isReady;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static async void Initialize()
    {
        foreach (TMP_Text text in UnityEngine.Object.FindObjectsByType<TMP_Text>(
                     FindObjectsInactive.Include,
                     FindObjectsSortMode.None))
            if (text != null)
                SceneStartupTextIds.Add(text.GetInstanceID());

        TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(OnTextChanged);
        TMPro_EventManager.TEXT_CHANGED_EVENT.Add(OnTextChanged);

        await LocalizationSettings.InitializationOperation.Task;
        var koreanLocale = LocalizationSettings.AvailableLocales.Locales
            .FirstOrDefault(locale => locale.Identifier.Code.StartsWith("ko", StringComparison.OrdinalIgnoreCase));
        if (koreanLocale == null)
            return;

        StringTable koreanTable = await LocalizationSettings.StringDatabase
            .GetTableAsync(GameLocalization.TableName, koreanLocale).Task;
        if (koreanTable == null)
            return;

        resolver = new LocalizationBindingResolver(koreanTable.Values
            .Select(entry => new LocalizationBindingEntry(entry.Key, NormalizeKoreanSource(entry.Value))));

        isReady = true;
    }

    private static void OnTextChanged(UnityEngine.Object changedObject)
    {
        if (changedObject is not TMP_Text text)
            return;

        if (SceneStartupTextIds.Contains(text.GetInstanceID()))
        {
            LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", "KnownAtSceneStart");
            return;
        }

        TryAttach(text);
    }

    private static void TryAttach(TMP_Text text)
    {
        if (text == null)
            return;

        if (!isReady)
        {
            LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", "NotReady");
            return;
        }

        if (!LocalizedTMPText.ShouldManageText(text))
        {
            LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", "ShouldManageText=false");
            return;
        }

        if (text.GetComponent<LocalizedTMPText>() != null)
        {
            LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", "LocalizedTMPTextAlreadyExists");
            return;
        }

        int instanceId = text.GetInstanceID();
        if (!ProcessingTextIds.Add(instanceId))
        {
            LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", "AlreadyProcessing");
            return;
        }

        try
        {
            string koreanSource = NormalizeKoreanSource(text.text);
            LocalizationKeyResolution resolution = resolver.ResolveSource(koreanSource);
            if (!LocalizationTextRules.IsKoreanPlayerText(koreanSource) || !resolution.IsUnique)
            {
                LocalizationHoverDiagnostics.LogAutoLocalizer(text, "SKIP", !LocalizationTextRules.IsKoreanPlayerText(koreanSource) ? "NotKoreanPlayerText" : "ResolutionNotUnique");
                return;
            }

            LocalizedTMPText localizer = text.GetComponent<LocalizedTMPText>();
            if (localizer == null)
            {
                LocalizationHoverDiagnostics.LogAutoLocalizer(text, "ATTACH", "UniqueKoreanSource");
                localizer = text.gameObject.AddComponent<LocalizedTMPText>();
            }

            if (!string.Equals(localizer.LocalizationKey, resolution.Key, StringComparison.Ordinal) ||
                !string.Equals(localizer.KoreanSource, koreanSource, StringComparison.Ordinal))
            {
                LocalizationHoverDiagnostics.LogAutoLocalizer(text, "CONFIGURE", "KeyOrKoreanSourceChanged");
                localizer.Configure(resolution.Key, koreanSource, true);
            }
        }
        finally
        {
            ProcessingTextIds.Remove(instanceId);
        }
    }

    public static string NormalizeKoreanSource(string source)
    {
        return string.IsNullOrWhiteSpace(source)
            ? string.Empty
            : source.Replace("\r\n", "\n").Trim();
    }

    public static bool WasKnownAtSceneStart(TMP_Text text) =>
        text != null && SceneStartupTextIds.Contains(text.GetInstanceID());
}

/// <summary>
/// Temporary runtime diagnostics for the two hover TMP writers.
/// This class only observes and logs state; it never changes localization behavior.
/// </summary>
public static class LocalizationHoverDiagnostics
{
    private static readonly HashSet<int> TrackedTextIds = new();

    public static void Track(TMP_Text text, string source)
    {
        if (text == null)
        {
            Debug.Log($"[HoverDiagnostics TRACK] Source: {source}\nTarget: <null>");
            return;
        }

        TrackedTextIds.Add(text.GetInstanceID());
        Debug.Log($"[HoverDiagnostics TRACK]\nSource: {source}\n{Describe(text)}");
    }

    public static bool IsTracked(TMP_Text text) => text != null && TrackedTextIds.Contains(text.GetInstanceID());

    public static void LogWriterBefore(string writer, TMP_Text text, string incomingText)
    {
        Track(text, writer);
        Debug.Log($"[{writer} BEFORE]\n{Describe(text)}\nPreviousText: {text?.text ?? "<null>"}\nIncomingText: {incomingText ?? "<null>"}");
    }

    public static void LogWriterAfter(string writer, TMP_Text text) =>
        Debug.Log($"[{writer} AFTER]\n{Describe(text)}\nResultText: {text?.text ?? "<null>"}");

    public static void LogAutoLocalizer(TMP_Text text, string decision, string reason)
    {
        if (!IsTracked(text))
            return;

        Debug.Log($"[AutoLocalizer TEXT_CHANGED]\n{Describe(text)}\nCurrentText: {text.text}\nKnownAtSceneStart: {RuntimeTMPTextAutoLocalizer.WasKnownAtSceneStart(text)}\nIsRuntimeCreated: {!RuntimeTMPTextAutoLocalizer.WasKnownAtSceneStart(text)}\nAction: {decision}\nReason: {reason}");
    }

    public static void LogRefresh(TMP_Text text, string before, string resolved, string after, string reason)
    {
        if (IsTracked(text))
            Debug.Log($"[LocalizedTMPText.Refresh]\n{Describe(text)}\nBefore: {before}\nResolved: {resolved}\nAfter: {after}\nCall reason: {reason}");
    }

    public static string Describe(TMP_Text text)
    {
        if (text == null)
            return "Target: <null>\nFull Hierarchy Path: <null>\nTMP InstanceID: <null>\nGameObject InstanceID: <null>";

        LocalizationIgnore selfIgnore = text.GetComponent<LocalizationIgnore>();
        LocalizationIgnore parentIgnore = text.GetComponentInParent<LocalizationIgnore>(true);
        LocalizedTMPText localizer = text.GetComponent<LocalizedTMPText>();
        StringBuilder builder = new();
        builder.Append("Target: ").Append(text.name).Append('\n');
        builder.Append("Full Hierarchy Path: ").Append(GetHierarchyPath(text.transform)).Append('\n');
        builder.Append("TMP InstanceID: ").Append(text.GetInstanceID()).Append('\n');
        builder.Append("GameObject InstanceID: ").Append(text.gameObject.GetInstanceID()).Append('\n');
        builder.Append("LocalizationIgnore Self: ").Append(selfIgnore != null).Append('\n');
        builder.Append("LocalizationIgnore Parent: ").Append(parentIgnore != null).Append('\n');
        builder.Append("LocalizedTMPText exists: ").Append(localizer != null).Append('\n');
        builder.Append("LocalizedTMPText.enabled: ").Append(localizer != null && localizer.enabled).Append('\n');
        builder.Append("LocalizationKey: ").Append(localizer != null ? localizer.LocalizationKey : "<none>").Append('\n');
        builder.Append("KoreanSource: ").Append(localizer != null ? localizer.KoreanSource : "<none>");
        return builder.ToString();
    }

    private static string GetHierarchyPath(Transform transform)
    {
        if (transform == null)
            return "<null>";

        StringBuilder builder = new(transform.name);
        for (Transform current = transform.parent; current != null; current = current.parent)
            builder.Insert(0, current.name + "/");
        return builder.ToString();
    }
}

[DisallowMultipleComponent]
public sealed class CompoundReferenceNameTooltipDiagnostics : MonoBehaviour
{
    private TMP_Text nameText;

    private void Awake()
    {
        nameText = GetComponentInChildren<TMP_Text>(true);
        LocalizationHoverDiagnostics.Track(nameText, "CompoundReferenceNameTooltip.Show/NameinfoTarget");
    }

    private void OnEnable() => TMPro_EventManager.TEXT_CHANGED_EVENT.Add(OnTextChanged);
    private void OnDisable() => TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(OnTextChanged);

    private void OnTextChanged(UnityEngine.Object changedObject)
    {
        if (changedObject == nameText)
            Debug.Log($"[CompoundReferenceNameTooltip.Show OBSERVED]\n{LocalizationHoverDiagnostics.Describe(nameText)}\nPreviousText: <unavailable: assignment already completed>\nIncomingText: {nameText.text}\nResultText: {nameText.text}");
    }
}

public static class CompoundReferenceNameTooltipDiagnosticsBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Attach()
    {
        CompoundReferenceNameTooltip[] tooltips = UnityEngine.Object.FindObjectsByType<CompoundReferenceNameTooltip>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (CompoundReferenceNameTooltip tooltip in tooltips)
            if (tooltip.GetComponent<CompoundReferenceNameTooltipDiagnostics>() == null)
                tooltip.gameObject.AddComponent<CompoundReferenceNameTooltipDiagnostics>();
    }
}
