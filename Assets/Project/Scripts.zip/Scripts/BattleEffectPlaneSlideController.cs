using System.Collections;
using UnityEngine;

/// <summary>
/// ���� ���� �� ���� ��� ȿ�� Plane 2���� ȭ�� �߾����� ��Ҵٰ�,
/// �ٽ� �ൿ ���� ���� ���ƿ��� ���� ��ġ�� �ǵ����ϴ�.
/// BattleEffect ������Ʈ�� ���̰� leftPlane/rightPlane�� Plane, Plane (1)�� �����ؼ� ����մϴ�.
/// </summary>
public class BattleEffectPlaneSlideController : MonoBehaviour
{
    public static BattleEffectPlaneSlideController Instance { get; private set; }

    [Header("Target Planes")]
    [SerializeField] private Transform leftPlane;
    [SerializeField] private Transform rightPlane;

    [Header("Battle Position")]
    [SerializeField] private float battleCenterX = 0f;
    [SerializeField] private bool cacheStartPositionOnAwake = true;
    [SerializeField] private Vector3 leftReservePosition = new Vector3(-50f, 0f, 0f);
    [SerializeField] private Vector3 rightReservePosition = new Vector3(50f, 0f, 0f);

    [Header("Camera Follow")]
    [SerializeField] private bool followCameraPosition = true;
    [SerializeField] private Camera followCamera;
    [SerializeField] private bool autoFindFollowCamera = true;
    [SerializeField] private bool followCameraX = true;
    // ���� ī�޶� �׸��� ��ġ�� ������ �� X/Y�� ���� �����̹Ƿ�,
    // Plane�� ī�޶��� X/Y �̵����� ���� ���󰡰� �մϴ�.
    [SerializeField] private bool followCameraY = true;
    [SerializeField] private bool followCameraZ = false;
    [SerializeField] private bool updateFollowInLateUpdate = true;

    [Header("Camera Zoom Y Follow")]
    [SerializeField] private bool adjustYByCameraZ = true;
    [SerializeField] private float referenceCameraZ = -20f;
    [SerializeField] private float zoomCameraZ = -13f;
    [SerializeField] private bool clampCameraZoomLerp = true;
    [SerializeField] private float leftYAtReferenceZ = -4.5f;
    [SerializeField] private float leftYAtZoomZ = -3.5f;
    [SerializeField] private float rightYAtReferenceZ = 5f;
    [SerializeField] private float rightYAtZoomZ = 4f;

    [Header("Camera Y Direction Zoom Compensation")]
    [SerializeField] private bool adjustZoomTargetByCameraY = true;
    [SerializeField, Min(0f)] private float cameraYDirectionDeadZone = 0.05f;
    [SerializeField] private float leftYAtZoomZWhenCameraYMinus = -4.5f;
    [SerializeField] private float rightYAtZoomZWhenCameraYMinus = 3f;
    [SerializeField] private float rightYAtZoomZWhenCameraYPlus = 4.5f;

    [Header("Foreground Sorting")]
    [SerializeField, Min(1)] private int foregroundSortingOrderOffset = 100;

    [Header("Animation")]
    [SerializeField, Min(0f)] private float moveDuration = 0.35f;
    [SerializeField] private AnimationCurve moveCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
    [SerializeField] private bool snapToReservePositionOnStart = true;

    private Coroutine moveRoutine;
    private bool cachedPositions;
    private float slide01;
    private Vector3 referenceCameraPosition;
    private bool hasReferenceCameraPosition;

    private void Awake()
    {
        Instance = this;

        ResolveFollowCamera();
        CaptureReferenceCameraPosition();

        if (cacheStartPositionOnAwake)
            CacheCurrentReservePositions();
    }

    private void Start()
    {
        ResolveFollowCamera();

        if (!hasReferenceCameraPosition)
            CaptureReferenceCameraPosition();

        if (!cachedPositions)
            CacheCurrentReservePositions();

        if (snapToReservePositionOnStart)
            SetReservePositionInstant();
    }

    private void LateUpdate()
    {
        if (!updateFollowInLateUpdate)
            return;

        // ī�޶� ��ġ ������ �� ���¶�, ī�޶� Z Ȯ�뿡 ���� Y ������ ��� ���ŵǾ�� �մϴ�.
        if (!followCameraPosition && !adjustYByCameraZ)
            return;

        ApplyPlanePositions(slide01);
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    public bool TryGetForegroundSorting(out int sortingLayerId, out int sortingOrder)
    {
        sortingLayerId = 0;
        sortingOrder = 30000;

        Renderer bestRenderer = null;
        int bestLayerValue = int.MinValue;
        int bestOrder = int.MinValue;

        EvaluatePlaneRenderers(leftPlane, ref bestRenderer, ref bestLayerValue, ref bestOrder);
        EvaluatePlaneRenderers(rightPlane, ref bestRenderer, ref bestLayerValue, ref bestOrder);

        if (bestRenderer == null)
            return false;

        sortingLayerId = bestRenderer.sortingLayerID;
        sortingOrder = bestOrder + Mathf.Max(1, foregroundSortingOrderOffset);
        return true;
    }

    private static void EvaluatePlaneRenderers(
        Transform plane,
        ref Renderer bestRenderer,
        ref int bestLayerValue,
        ref int bestOrder)
    {
        if (plane == null)
            return;

        Renderer[] renderers = plane.GetComponentsInChildren<Renderer>(true);

        for (int i = 0; i < renderers.Length; i++)
        {
            Renderer renderer = renderers[i];
            if (renderer == null)
                continue;

            int layerValue = SortingLayer.GetLayerValueFromID(renderer.sortingLayerID);

            if (bestRenderer == null ||
                layerValue > bestLayerValue ||
                (layerValue == bestLayerValue && renderer.sortingOrder > bestOrder))
            {
                bestRenderer = renderer;
                bestLayerValue = layerValue;
                bestOrder = renderer.sortingOrder;
            }
        }
    }

    private void OnEnable()
    {
        BattleTurnExecutor.BattleExecutionStarted -= MoveToBattleCenter;
        BattleTurnExecutor.BattleExecutionStarted += MoveToBattleCenter;

        BattleTurnExecutor.PlayerTurnReturned -= MoveToReservePosition;
        BattleTurnExecutor.PlayerTurnReturned += MoveToReservePosition;
    }

    private void OnDisable()
    {
        BattleTurnExecutor.BattleExecutionStarted -= MoveToBattleCenter;
        BattleTurnExecutor.PlayerTurnReturned -= MoveToReservePosition;
        BattleActionForegroundRenderer.ClearAll();
    }

    public void MoveToBattleCenter()
    {
        if (!isActiveAndEnabled)
            return;

        if (!cachedPositions)
            CacheCurrentReservePositions();

        PlayMove(1f);
    }

    public void MoveToReservePosition()
    {
        BattleActionForegroundRenderer.ClearAll();

        if (!isActiveAndEnabled)
            return;

        if (!cachedPositions)
            CacheCurrentReservePositions();

        PlayMove(0f);
    }

    public void SetReservePositionInstant()
    {
        if (!cachedPositions)
            CacheCurrentReservePositions();

        slide01 = 0f;
        ApplyPlanePositions(slide01);
    }

    public void ForceResetToReservePositionInstant()
    {
        BattleActionForegroundRenderer.ClearAll();

        if (moveRoutine != null)
        {
            StopCoroutine(moveRoutine);
            moveRoutine = null;
        }

        if (!cachedPositions)
            CacheCurrentReservePositions();

        slide01 = 0f;
        ApplyPlanePositions(slide01);
    }

    private void CacheCurrentReservePositions()
    {
        if (leftPlane != null)
            leftReservePosition = leftPlane.localPosition;

        if (rightPlane != null)
            rightReservePosition = rightPlane.localPosition;

        cachedPositions = true;
    }

    private void ResolveFollowCamera()
    {
        if (!autoFindFollowCamera)
            return;

        if (followCamera != null)
            return;

        followCamera = Camera.main;

        if (followCamera != null)
            return;

        BattleCameraController battleCameraController = BattleCameraController.Instance;
        if (battleCameraController == null)
            return;

        followCamera = battleCameraController.GetComponent<Camera>();
        if (followCamera == null)
            followCamera = battleCameraController.GetComponentInChildren<Camera>();
    }

    private void CaptureReferenceCameraPosition()
    {
        ResolveFollowCamera();

        if (followCamera == null)
            return;

        referenceCameraPosition = followCamera.transform.position;
        hasReferenceCameraPosition = true;
    }

    private void PlayMove(float targetSlide01)
    {
        if (moveRoutine != null)
            StopCoroutine(moveRoutine);

        moveRoutine = StartCoroutine(MoveRoutine(targetSlide01));
    }

    private IEnumerator MoveRoutine(float targetSlide01)
    {
        float startSlide01 = slide01;
        float duration = Mathf.Max(0f, moveDuration);

        if (duration <= 0f)
        {
            slide01 = Mathf.Clamp01(targetSlide01);
            ApplyPlanePositions(slide01);
            moveRoutine = null;
            yield break;
        }

        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float curveT = moveCurve != null ? moveCurve.Evaluate(t) : t;

            slide01 = Mathf.LerpUnclamped(startSlide01, targetSlide01, curveT);
            ApplyPlanePositions(slide01);

            yield return null;
        }

        slide01 = Mathf.Clamp01(targetSlide01);
        ApplyPlanePositions(slide01);
        moveRoutine = null;
    }

    private void ApplyPlanePositions(float t)
    {
        if (!cachedPositions)
            CacheCurrentReservePositions();

        ResolveFollowCamera();

        if (followCameraPosition && !hasReferenceCameraPosition)
            CaptureReferenceCameraPosition();

        if (leftPlane != null)
        {
            Vector3 leftBattlePosition = GetBattlePosition(leftReservePosition);
            Vector3 leftBasePosition = Vector3.LerpUnclamped(leftReservePosition, leftBattlePosition, t);
            leftBasePosition.y = GetCameraZoomAdjustedY(leftBasePosition.y, true);
            leftPlane.localPosition = ApplyCameraDeltaToLocalPosition(leftPlane, leftBasePosition);
        }

        if (rightPlane != null)
        {
            Vector3 rightBattlePosition = GetBattlePosition(rightReservePosition);
            Vector3 rightBasePosition = Vector3.LerpUnclamped(rightReservePosition, rightBattlePosition, t);
            rightBasePosition.y = GetCameraZoomAdjustedY(rightBasePosition.y, false);
            rightPlane.localPosition = ApplyCameraDeltaToLocalPosition(rightPlane, rightBasePosition);
        }
    }

    private Vector3 GetBattlePosition(Vector3 reservePosition)
    {
        reservePosition.x = battleCenterX;
        return reservePosition;
    }

    private float GetCameraZoomAdjustedY(float fallbackY, bool isLeftPlane)
    {
        if (!adjustYByCameraZ)
            return fallbackY;

        ResolveFollowCamera();
        if (followCamera == null)
            return fallbackY;

        // ī�޶� �׸��� ��ġ�� ���� -20���� -13���� ���� ���� �ʰ� �߰� ������ ���絵,
        // ���� ī�޶� Z���� �״�� ����� Plane Y���� ���� ������ �����մϴ�.
        float zoomT = GetCameraZoomLerp01();

        if (isLeftPlane)
            return Mathf.LerpUnclamped(leftYAtReferenceZ, GetLeftZoomTargetY(), zoomT);

        return Mathf.LerpUnclamped(rightYAtReferenceZ, GetRightZoomTargetY(), zoomT);
    }

    private float GetLeftZoomTargetY()
    {
        if (!adjustZoomTargetByCameraY)
            return leftYAtZoomZ;

        float cameraDeltaY = GetCameraDeltaY();

        // ī�޶� �Ʒ������� �̵��ϴ� �׸��� ��ġ������ �Ʒ� Plane�� �ö���� �ʵ���
        // -3.5 ��� -4.5�� �ӹ��� �մϴ�.
        if (cameraDeltaY < -cameraYDirectionDeadZone)
            return leftYAtZoomZWhenCameraYMinus;

        return leftYAtZoomZ;
    }

    private float GetRightZoomTargetY()
    {
        if (!adjustZoomTargetByCameraY)
            return rightYAtZoomZ;

        float cameraDeltaY = GetCameraDeltaY();

        // ī�޶� �Ʒ������� �̵��ϴ� �׸��� ��ġ������ �� Plane�� �� ������
        // 4 ��� 3���� �����մϴ�.
        if (cameraDeltaY < -cameraYDirectionDeadZone)
            return rightYAtZoomZWhenCameraYMinus;

        // ī�޶� �������� �̵��ϴ� �׸��� ��ġ������ �� Plane�� �ʹ� ���� �������� �ʵ���
        // 4 ��� 4.5������ �����մϴ�.
        if (cameraDeltaY > cameraYDirectionDeadZone)
            return rightYAtZoomZWhenCameraYPlus;

        return rightYAtZoomZ;
    }

    private float GetCameraDeltaY()
    {
        if (followCamera == null || !hasReferenceCameraPosition)
            return 0f;

        return followCamera.transform.position.y - referenceCameraPosition.y;
    }

    private float GetCameraZoomLerp01()
    {
        if (followCamera == null)
            return 0f;

        float range = zoomCameraZ - referenceCameraZ;
        if (Mathf.Approximately(range, 0f))
            return 0f;

        float t = (followCamera.transform.position.z - referenceCameraZ) / range;
        return clampCameraZoomLerp ? Mathf.Clamp01(t) : t;
    }

    private Vector3 ApplyCameraDeltaToLocalPosition(Transform target, Vector3 baseLocalPosition)
    {
        if (!followCameraPosition)
            return baseLocalPosition;

        if (followCamera == null || !hasReferenceCameraPosition)
            return baseLocalPosition;

        Vector3 cameraDelta = followCamera.transform.position - referenceCameraPosition;

        if (!followCameraX)
            cameraDelta.x = 0f;

        if (!followCameraY)
            cameraDelta.y = 0f;

        if (!followCameraZ)
            cameraDelta.z = 0f;

        if (target.parent == null)
            return baseLocalPosition + cameraDelta;

        Vector3 baseWorldPosition = target.parent.TransformPoint(baseLocalPosition);
        Vector3 targetWorldPosition = baseWorldPosition + cameraDelta;
        return target.parent.InverseTransformPoint(targetWorldPosition);
    }
}
